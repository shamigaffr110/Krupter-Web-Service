ElectricityBillingSolution - Complete solution (Web App + DB helper)
Generated: 2025-08-27T20:25:23.001680

Contents:
- DBHelperLib: Class library with SqlHelper (reads connection string 'EBillDB' from web.config).
- ElectricityBillingSystem: ASP.NET Web Application (4.7.2) with full functionality:
  - User registration/login, dashboard, view bills, transaction history, apply connection
  - Admin login/dashboard, approve/reject connections, assign consumer number
  - Generate multiple bills, fetch last N bills, revenue report, defaulter emails
  - Printable bill receipt and PDF export using iTextSharp (NuGet)
  - QR payment simulation page (QRCode.js via CDN), email receipts via SMTP (configure in web.config)

Important steps to run:
1. Unzip the ZIP and open ElectricityBillingSolution.sln in Visual Studio 2017/2019/2022.
2. Restore NuGet packages (iTextSharp) via Visual Studio / NuGet package manager.
3. Execute 'ElectricityBillingSystem/App_Data/EBillDB.sql' against (LocalDB)\MSSQLLocalDB or your SQL Server to create DB and seed data.
4. Build solution and run ElectricityBillingSystem as startup project.
5. Configure SMTP settings in Web.config for email sending (or leave as placeholders).

Seeded credentials:
- Admin: admin@ebill.local / Admin@123
- User: user1@ebill.local / User@123

Note: Replace plain-text seeded passwords with proper hashing for production.
