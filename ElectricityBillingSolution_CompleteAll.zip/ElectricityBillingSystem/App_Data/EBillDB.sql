-- EBillDB schema and seed data (run on LocalDB or SQL Server)
CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200),
    Email NVARCHAR(200) UNIQUE,
    Password NVARCHAR(200),
    Mobile NVARCHAR(50),
    CreatedOn DATETIME DEFAULT GETDATE()
);

CREATE TABLE Admins (
    AdminId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200),
    Email NVARCHAR(200) UNIQUE,
    Password NVARCHAR(200),
    CreatedOn DATETIME DEFAULT GETDATE()
);

CREATE TABLE Connections (
    ConnectionId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NULL,
    ConsumerNumber NVARCHAR(20) NULL,
    Address NVARCHAR(500),
    Locality NVARCHAR(100),
    IsUrban BIT DEFAULT 1,
    ConnectionType NVARCHAR(50),
    Phase NVARCHAR(50),
    MeterType NVARCHAR(50),
    IdProof NVARCHAR(200),
    PhotoPath NVARCHAR(500),
    Mobile NVARCHAR(50),
    Email NVARCHAR(200),
    Status NVARCHAR(50) DEFAULT 'Pending', -- Pending, Approved, Rejected
    CreatedOn DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

CREATE TABLE Bills (
    BillId INT IDENTITY(1,1) PRIMARY KEY,
    ConnectionId INT,
    BillingMonth DATE,
    UnitsConsumed INT,
    Amount DECIMAL(18,2),
    DueDate DATE,
    IsPaid BIT DEFAULT 0,
    CreatedOn DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ConnectionId) REFERENCES Connections(ConnectionId)
);

CREATE TABLE Payments (
    PaymentId INT IDENTITY(1,1) PRIMARY KEY,
    BillId INT,
    PaymentDate DATETIME DEFAULT GETDATE(),
    AmountPaid DECIMAL(18,2),
    TransactionRef NVARCHAR(200),
    FOREIGN KEY (BillId) REFERENCES Bills(BillId)
);

CREATE TABLE Notices (
    NoticeId INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(300),
    Message NVARCHAR(MAX),
    CreatedOn DATETIME DEFAULT GETDATE()
);

CREATE TABLE Concerns (
    ConcernId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT,
    Subject NVARCHAR(200),
    Message NVARCHAR(MAX),
    Status NVARCHAR(50) DEFAULT 'Open',
    CreatedOn DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

-- Seed admin and a user
INSERT INTO Admins (FullName, Email, Password) VALUES ('Site Admin','admin@ebill.local','Admin@123');
INSERT INTO Users (FullName, Email, Password, Mobile) VALUES ('Test User','user1@ebill.local','User@123','9999999999');

-- Seed a connection (approved) and an old unpaid bill to act as defaulter (>1 year)
INSERT INTO Connections (UserId, ConsumerNumber, Address, Locality, IsUrban, ConnectionType, Phase, MeterType, Mobile, Email, Status)
VALUES (1, 'EB10001', '123 Main St', 'Zone A', 1, 'Domestic', 'Single', 'Smart', '9999999999', 'user1@ebill.local', 'Approved');

-- Recent unpaid bill
INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid)
VALUES (1, DATEADD(month, -1, GETDATE()), 220, 330.00, DATEADD(day, 15, DATEADD(month, -1, GETDATE())), 0);

-- Old unpaid bill > 1 year (defaulter)
INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid, CreatedOn)
VALUES (1, DATEADD(month, -14, GETDATE()), 1500, 7500.00, DATEADD(day, 30, DATEADD(month, -14, GETDATE())), 0, DATEADD(month, -14, GETDATE()));

-- Seed a paid bill with payment record
INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid)
VALUES (1, DATEADD(month, -3, GETDATE()), 120, 180.00, DATEADD(day, 15, DATEADD(month, -3, GETDATE())), 1);

INSERT INTO Payments (BillId, PaymentDate, AmountPaid, TransactionRef)
VALUES (3, DATEADD(month, -2, GETDATE()), 180.00, 'TXN1001');

-- Sample notice
INSERT INTO Notices (Title, Message) VALUES ('Welcome','Welcome to the Electricity Billing System.');