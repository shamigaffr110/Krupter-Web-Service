using System;
using System.Data;
using System.Net.Mail;
using DBHelperLib;

public partial class Admin_Defaulters : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { if (Session["AdminId"]==null) Response.Redirect("/Admin/AdminLogin.aspx"); if(!IsPostBack) LoadDefaulters(); }

    private void LoadDefaulters()
    {
        // bills older than 365 days and unpaid
        var dt = SqlHelper.ExecuteDataTable(@"SELECT b.BillId, c.ConsumerNumber, u.FullName, b.Amount, u.Email FROM Bills b 
                                            JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId
                                            WHERE b.IsPaid=0 AND DATEDIFF(day, b.CreatedOn, GETDATE()) > 365");
        gvDef.DataSource = dt; gvDef.DataBind();
    }

    protected void gvDef_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        int billId = Convert.ToInt32(gvDef.DataKeys[rowIndex].Value);
        var dt = SqlHelper.ExecuteDataTable("SELECT u.Email, c.ConsumerNumber FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE b.BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
        if (dt.Rows.Count==0) return;
        var email = dt.Rows[0]["Email"].ToString();
        try
        {
            var mail = new MailMessage("no-reply@example.com", email);
            mail.Subject = "Legal Notice: Outstanding Electricity Bill";
            mail.Body = "Your bill is unpaid for more than 1 year. Please contact the office. Amount: " + dt.Rows[0]["Amount"];
            var client = new SmtpClient();
            client.Send(mail);
            lblMsg.Text = "Notice sent (if SMTP configured).";
        }
        catch (Exception ex) { lblMsg.Text = "Email failed: " + ex.Message; }
    }
}