using System;
using System.Data;
using DBHelperLib;

public partial class Admin_AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["AdminId"] == null) Response.Redirect("/Admin/AdminLogin.aspx");
        if (!IsPostBack) LoadPending();
    }

    private void LoadPending()
    {
        var dt = SqlHelper.ExecuteDataTable("SELECT ConnectionId, Address, Mobile FROM Connections WHERE Status='Pending' ORDER BY CreatedOn");
        rptPending.DataSource = dt;
        rptPending.DataBind();
    }

    protected void Approve_Command(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        // assign consumer number as EB + padded id
        string consumer = "EB" + (10000 + id).ToString();
        SqlHelper.ExecuteNonQuery("UPDATE Connections SET Status='Approved', ConsumerNumber=@c WHERE ConnectionId=@id", new System.Data.SqlClient.SqlParameter("@c", consumer), new System.Data.SqlClient.SqlParameter("@id", id));
        LoadPending();
    }

    protected void Reject_Command(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        SqlHelper.ExecuteNonQuery("UPDATE Connections SET Status='Rejected' WHERE ConnectionId=@id", new System.Data.SqlClient.SqlParameter("@id", id));
        LoadPending();
    }
}