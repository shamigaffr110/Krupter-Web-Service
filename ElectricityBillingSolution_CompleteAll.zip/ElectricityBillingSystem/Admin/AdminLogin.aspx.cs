using System;
using DBHelperLib;
using System.Data;

public partial class Admin_AdminLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        var dt = SqlHelper.ExecuteDataTable("SELECT AdminId, FullName FROM Admins WHERE Email=@e AND Password=@p", new System.Data.SqlClient.SqlParameter("@e", txtEmail.Text.Trim()), new System.Data.SqlClient.SqlParameter("@p", txtPassword.Text.Trim()));
        if (dt.Rows.Count > 0)
        {
            Session["AdminId"] = dt.Rows[0]["AdminId"];
            Session["AdminName"] = dt.Rows[0]["FullName"];
            Response.Redirect("/Admin/AdminDashboard.aspx");
        }
        else lblMsg.Text = "Invalid credentials";
    }
}