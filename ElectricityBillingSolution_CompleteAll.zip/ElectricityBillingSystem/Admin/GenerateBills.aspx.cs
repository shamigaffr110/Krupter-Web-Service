using System;
using System.Data;
using System.Web.UI.WebControls;
using DBHelperLib;

public partial class Admin_GenerateBills : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { }

    protected void btnStart_Click(object sender, EventArgs e)
    {
        phInputs.Controls.Clear();
        string consumer = txtConsumer.Text.Trim();
        int count = 1;
        int.TryParse(txtCount.Text.Trim(), out count);
        for (int i = 0; i < count; i++)
        {
            var div = new Panel();
            div.Controls.Add(new LiteralControl($"<div class='mb-2'><strong>Bill #{i+1}</strong><br/>"));
            var txtUnits = new TextBox() { ID = "txtUnits_" + i, CssClass = "form-control" };
            div.Controls.Add(new LiteralControl("Units: "));
            div.Controls.Add(txtUnits);
            var txtMonth = new TextBox() { ID = "txtMonth_" + i, CssClass = "form-control", Text = DateTime.Now.ToString("yyyy-MM-01") };
            div.Controls.Add(new LiteralControl(" BillingMonth (yyyy-MM-01): "));
            div.Controls.Add(txtMonth);
            phInputs.Controls.Add(div);
        }
        var btn = new Button() { Text = "Generate Now", CssClass = "btn btn-success", ID = "btnGenerate" };
        btn.Click += Btn_Click;
        phInputs.Controls.Add(btn);
    }

    private void Btn_Click(object sender, EventArgs e)
    {
        // find consumer id
        var dtc = SqlHelper.ExecuteDataTable("SELECT ConnectionId FROM Connections WHERE ConsumerNumber=@c", new System.Data.SqlClient.SqlParameter("@c", txtConsumer.Text.Trim()));
        if (dtc.Rows.Count == 0) { lblMsg.Text = "Consumer not found."; return; }
        int connId = Convert.ToInt32(dtc.Rows[0]["ConnectionId"]);
        int idx = 0;
        while (true)
        {
            var txtUnits = phInputs.FindControl("txtUnits_" + idx) as TextBox;
            var txtMonth = phInputs.FindControl("txtMonth_" + idx) as TextBox;
            if (txtUnits == null) break;
            int units = 0; DateTime month = DateTime.Now;
            int.TryParse(txtUnits.Text.Trim(), out units);
            DateTime.TryParse(txtMonth.Text.Trim(), out month);
            decimal amount = CalculateAmount(units);
            SqlHelper.ExecuteNonQuery("INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid) VALUES (@cid,@m,@u,@a,@d,0)",
                new System.Data.SqlClient.SqlParameter("@cid", connId),
                new System.Data.SqlClient.SqlParameter("@m", month),
                new System.Data.SqlClient.SqlParameter("@u", units),
                new System.Data.SqlClient.SqlParameter("@a", amount),
                new System.Data.SqlClient.SqlParameter("@d", month.AddDays(15))
            );
            idx++;
        }
        lblMsg.Text = "Bills generated.";
    }

    private decimal CalculateAmount(int units)
    {
        decimal amt = 0;
        int remaining = units;
        if (remaining <= 100) return 0;
        remaining -= 100;
        int slab = Math.Min(200, remaining); amt += slab * 1.5m; remaining -= slab; if (remaining<=0) return amt;
        slab = Math.Min(300, remaining); amt += slab * 3.5m; remaining -= slab; if (remaining<=0) return amt;
        slab = Math.Min(400, remaining); amt += slab * 5.5m; remaining -= slab; if (remaining<=0) return amt;
        if (remaining>0) amt += remaining * 7.5m;
        return amt;
    }
}