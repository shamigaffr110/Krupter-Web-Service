using System;
using System.Data;
using DBHelperLib;

public partial class Admin_RevenueReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { if (Session["AdminId"]==null) Response.Redirect("/Admin/AdminLogin.aspx"); if(!IsPostBack) LoadReport(); }

    private void LoadReport(string from=null, string to=null, string area=null)
    {
        string sql = "SELECT CONVERT(varchar(7), BillingMonth, 120) BillingMonth, SUM(Amount) Total FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId WHERE 1=1 ";
        if (!string.IsNullOrEmpty(from)) sql += " AND BillingMonth >= @from ";
        if (!string.IsNullOrEmpty(to)) sql += " AND BillingMonth <= @to ";
        if (!string.IsNullOrEmpty(area)) sql += " AND c.Locality = @area ";
        sql += " GROUP BY CONVERT(varchar(7), BillingMonth, 120) ORDER BY BillingMonth DESC";
        var parms = new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@from", (object)from ?? System.DBNull.Value),
            new System.Data.SqlClient.SqlParameter("@to", (object)to ?? System.DBNull.Value),
            new System.Data.SqlClient.SqlParameter("@area", (object)area ?? System.DBNull.Value)
        };
        var dt = SqlHelper.ExecuteDataTable(sql, parms);
        gvReport.DataSource = dt; gvReport.DataBind();
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadReport(txtFrom.Text.Trim(), txtTo.Text.Trim(), txtArea.Text.Trim());
    }
}