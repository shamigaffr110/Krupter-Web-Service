using System;
using System.Data;
using DBHelperLib;

public partial class Admin_Concerns_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { if (Session["AdminId"]==null) Response.Redirect("/Admin/AdminLogin.aspx"); if(!IsPostBack) Load(); }

    private void Load()
    {
        var dt = SqlHelper.ExecuteDataTable("SELECT co.ConcernId, u.FullName, co.Subject, co.Message, co.Status FROM Concerns co JOIN Users u ON co.UserId=u.UserId ORDER BY co.CreatedOn DESC");
        rptConcerns.DataSource = dt; rptConcerns.DataBind();
    }

    protected void Resolve_Command(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        SqlHelper.ExecuteNonQuery("UPDATE Concerns SET Status='Resolved' WHERE ConcernId=@id", new System.Data.SqlClient.SqlParameter("@id", id));
        Load();
    }
}