public partial class Account_Register {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.TextBox txtName;
    protected global::System.Web.UI.WebControls.TextBox txtEmail;
    protected global::System.Web.UI.WebControls.TextBox txtPassword;
    protected global::System.Web.UI.WebControls.TextBox txtMobile;
}