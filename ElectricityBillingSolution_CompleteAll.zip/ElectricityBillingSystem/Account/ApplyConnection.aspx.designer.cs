public partial class Account_ApplyConnection {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.TextBox txtName;
    protected global::System.Web.UI.WebControls.TextBox txtAddress;
    protected global::System.Web.UI.WebControls.TextBox txtDob;
    protected global::System.Web.UI.WebControls.TextBox txtLocality;
    protected global::System.Web.UI.WebControls.CheckBox chkUrban;
    protected global::System.Web.UI.WebControls.DropDownList ddlType;
    protected global::System.Web.UI.WebControls.DropDownList ddlPhase;
    protected global::System.Web.UI.WebControls.DropDownList ddlMeter;
    protected global::System.Web.UI.WebControls.TextBox txtIdProof;
    protected global::System.Web.UI.WebControls.TextBox txtMobile;
    protected global::System.Web.UI.WebControls.TextBox txtEmail;
}