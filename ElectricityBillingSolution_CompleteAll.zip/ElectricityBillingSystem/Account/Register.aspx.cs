using System;
using System.Data.SqlClient;
using DBHelperLib;

public partial class Account_Register : System.Web.UI.Page
{
    protected void btnReg_Click(object sender, EventArgs e)
    {
        try
        {
            string sql = "INSERT INTO Users (FullName, Email, Password, Mobile, CreatedOn) VALUES (@fn,@e,@p,@m,GETDATE())";
            int rows = SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@fn", txtName.Text.Trim()),
                new SqlParameter("@e", txtEmail.Text.Trim()),
                new SqlParameter("@p", txtPassword.Text.Trim()),
                new SqlParameter("@m", txtMobile.Text.Trim())
            );
            if (rows > 0) lblMsg.Text = "Registration successful. Please login.";
        }
        catch (Exception ex) { lblMsg.Text = "Error: " + ex.Message; }
    }
}