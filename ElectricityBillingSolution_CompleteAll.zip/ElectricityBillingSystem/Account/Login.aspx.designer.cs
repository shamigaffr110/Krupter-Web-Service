public partial class Account_Login {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.TextBox txtEmail;
    protected global::System.Web.UI.WebControls.TextBox txtPassword;
}