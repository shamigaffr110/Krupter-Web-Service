using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using DBHelperLib;

public partial class Account_Login : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            var dt = SqlHelper.ExecuteDataTable("SELECT UserId, FullName FROM Users WHERE Email=@e AND Password=@p",
                new SqlParameter("@e", txtEmail.Text.Trim()), new SqlParameter("@p", txtPassword.Text.Trim()));
            if (dt.Rows.Count > 0)
            {
                var uid = dt.Rows[0]["UserId"].ToString();
                FormsAuthentication.SetAuthCookie(txtEmail.Text.Trim(), false);
                Session["UserId"] = uid;
                Session["UserName"] = dt.Rows[0]["FullName"].ToString();
                Response.Redirect("/User/Dashboard.aspx");
            }
            else lblMsg.Text = "Invalid credentials";
        }
        catch (Exception ex) { lblMsg.Text = ex.Message; }
    }
}