using System;
using System.Data.SqlClient;
using DBHelperLib;

public partial class Account_ApplyConnection : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { }

    protected void btnApply_Click(object sender, EventArgs e)
    {
        try
        {
            string sql = @"INSERT INTO Connections (UserId, Address, Locality, IsUrban, ConnectionType, Phase, MeterType, IdProof, Mobile, Email, Status, CreatedOn)
                           VALUES (@uid,@addr,@loc,@urban,@type,@phase,@meter,@idp,@mobile,@email,'Pending',GETDATE())";
            int uid = Session["UserId"] != null ? Convert.ToInt32(Session["UserId"]) : (int?)null ?? 0;
            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@uid", uid),
                new SqlParameter("@addr", txtAddress.Text.Trim()),
                new SqlParameter("@loc", txtLocality.Text.Trim()),
                new SqlParameter("@urban", chkUrban.Checked ? 1 : 0),
                new SqlParameter("@type", ddlType.SelectedValue),
                new SqlParameter("@phase", ddlPhase.SelectedValue),
                new SqlParameter("@meter", ddlMeter.SelectedValue),
                new SqlParameter("@idp", txtIdProof.Text.Trim()),
                new SqlParameter("@mobile", txtMobile.Text.Trim()),
                new SqlParameter("@email", txtEmail.Text.Trim())
            );
            lblMsg.Text = "Application submitted. Please complete ₹8000 connection charge via QR (simulate) or contact support.";
        }
        catch (Exception ex) { lblMsg.Text = ex.Message; }
    }

    protected void btnPayCharge_Click(object sender, EventArgs e)
    {
        // Redirect to a simple QR payment simulation page with amount and purpose
        Response.Redirect($"/User/QRPayment.aspx?amount=8000&purpose=ConnectionCharge");
    }
}