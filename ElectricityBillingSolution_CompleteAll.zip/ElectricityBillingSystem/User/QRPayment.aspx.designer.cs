public partial class User_QRPayment {
    protected global::System.Web.UI.WebControls.Label lblMsg;
}