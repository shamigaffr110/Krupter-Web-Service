public partial class User_Dashboard {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.Literal litLatest;
    protected global::System.Web.UI.WebControls.Literal ltChartData;
}