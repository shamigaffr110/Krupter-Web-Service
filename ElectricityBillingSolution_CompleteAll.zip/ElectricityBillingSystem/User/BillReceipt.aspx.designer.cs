public partial class User_BillReceipt {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.Literal litReceipt;
}