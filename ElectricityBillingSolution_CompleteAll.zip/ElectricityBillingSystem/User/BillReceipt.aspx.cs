using System;
using System.Data;
using System.IO;
using System.Net.Mail;
using DBHelperLib;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class User_BillReceipt : System.Web.UI.Page
{
    protected int billId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null) Response.Redirect("/Account/Login.aspx");
        if (!IsPostBack) { if (int.TryParse(Request.QueryString["billId"], out billId)) LoadReceipt(billId); else lblMsg.Text = "No bill specified."; }
    }

    private void LoadReceipt(int id)
    {
        var dt = SqlHelper.ExecuteDataTable(@"SELECT b.BillId, c.ConsumerNumber, u.FullName, c.Address, b.BillingMonth, b.UnitsConsumed, b.Amount, b.DueDate, b.IsPaid
                                             FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE b.BillId=@id", new System.Data.SqlClient.SqlParameter("@id", id));
        if (dt.Rows.Count == 0) { lblMsg.Text = "Bill not found."; return; }
        var r = dt.Rows[0];
        string html = $@"<div id='receipt'>
            <h2>JBVNL - Electricity Bill Receipt</h2>
            <p><strong>Consumer:</strong> {r[""FullName""]} &nbsp; <strong>Consumer No:</strong> {r[""ConsumerNumber""]}</p>
            <p><strong>Billing Month:</strong> {Convert.ToDateTime(r[""BillingMonth""]).ToString("MMMM yyyy")}</p>
            <table style='width:100%;border-collapse:collapse' border='1'>
                <tr><th>Units</th><th>Amount (₹)</th></tr>
                <tr><td>{r[""UnitsConsumed""]}</td><td>{r[""Amount""]}</td></tr>
            </table>
            <p><strong>Due Date:</strong> {Convert.ToDateTime(r[""DueDate""]).ToShortDateString()} &nbsp; <strong>Status:</strong> {(Convert.ToBoolean(r[""IsPaid""])? "Paid":"Unpaid")}</p>
            <p>Thank you for using JBVNL.</p></div>";
        litReceipt.Text = html;
        billId = id;
    }

    protected void btnDownloadPdf_Click(object sender, EventArgs e)
    {
        // Generate PDF using iTextSharp
        var dt = SqlHelper.ExecuteDataTable("SELECT b.BillId, c.ConsumerNumber, u.FullName, c.Address, b.BillingMonth, b.UnitsConsumed, b.Amount, b.DueDate FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE b.BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
        if (dt.Rows.Count==0) { lblMsg.Text = "Bill not found."; return; }
        var r = dt.Rows[0];
        using (MemoryStream ms = new MemoryStream())
        {
            Document doc = new Document(PageSize.A4, 40,40,40,40);
            PdfWriter.GetInstance(doc, ms);
            doc.Open();
            var title = new Paragraph("JBVNL - Electricity Bill Receipt") { Alignment = Element.ALIGN_CENTER };
            doc.Add(title);
            doc.Add(new Paragraph(" "));
            PdfPTable table = new PdfPTable(2);
            table.WidthPercentage = 100;
            table.AddCell("Consumer");
            table.AddCell(r["FullName"].ToString());
            table.AddCell("Consumer No");
            table.AddCell(r["ConsumerNumber"].ToString());
            table.AddCell("Billing Month");
            table.AddCell(Convert.ToDateTime(r["BillingMonth"]).ToString("MMMM yyyy"));
            table.AddCell("Units");
            table.AddCell(r["UnitsConsumed"].ToString());
            table.AddCell("Amount (₹)");
            table.AddCell(r["Amount"].ToString());
            doc.Add(table);
            doc.Close();
            byte[] bytes = ms.ToArray();
            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", $"attachment; filename=Bill_{billId}.pdf");
            Response.OutputStream.Write(bytes, 0, bytes.Length);
            Response.Flush();
            Response.End();
        }
    }

    protected void btnEmail_Click(object sender, EventArgs e)
    {
        try
        {
            // generate PDF bytes as above and email as attachment
            var dt = SqlHelper.ExecuteDataTable("SELECT b.BillId, c.ConsumerNumber, u.FullName, c.Address, b.BillingMonth, b.UnitsConsumed, b.Amount, b.DueDate, u.Email FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE b.BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
            var r = dt.Rows[0];
            byte[] bytes;
            using (MemoryStream ms = new MemoryStream())
            {
                Document doc = new Document(PageSize.A4, 40,40,40,40);
                PdfWriter.GetInstance(doc, ms);
                doc.Open();
                doc.Add(new Paragraph("JBVNL - Electricity Bill Receipt"));
                doc.Add(new Paragraph(" "));
                PdfPTable table = new PdfPTable(2);
                table.WidthPercentage = 100;
                table.AddCell("Consumer"); table.AddCell(r["FullName"].ToString());
                table.AddCell("Consumer No"); table.AddCell(r["ConsumerNumber"].ToString());
                table.AddCell("Billing Month"); table.AddCell(Convert.ToDateTime(r["BillingMonth"]).ToString("MMMM yyyy"));
                table.AddCell("Units"); table.AddCell(r["UnitsConsumed"].ToString());
                table.AddCell("Amount (₹)"); table.AddCell(r["Amount"].ToString());
                doc.Add(table);
                doc.Close();
                bytes = ms.ToArray();
            }
            // Send email
            var mail = new MailMessage();
            mail.To.Add(r["Email"].ToString());
            mail.Subject = $"Your Electricity Bill - {Convert.ToDateTime(r["BillingMonth"]).ToString("MMMM yyyy")}";
            mail.Body = "Please find attached your bill receipt.";
            mail.From = new MailAddress("no-reply@example.com");
            mail.Attachments.Add(new Attachment(new MemoryStream(bytes), $"Bill_{billId}.pdf"));
            var client = new SmtpClient(); // settings from web.config
            client.Send(mail);
            lblMsg.Text = "Email sent (if SMTP configured).";
        }
        catch (Exception ex) { lblMsg.Text = "Email failed: " + ex.Message; }
    }
}