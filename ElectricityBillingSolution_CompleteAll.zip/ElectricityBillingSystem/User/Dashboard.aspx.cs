using System;
using System.Data;
using System.Text;
using DBHelperLib;

public partial class User_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null) Response.Redirect("/Account/Login.aspx");
        if (!IsPostBack) LoadLatestBillAndChart();
    }

    private void LoadLatestBillAndChart()
    {
        try
        {
            int userId = Convert.ToInt32(Session["UserId"]);
            var dt = SqlHelper.ExecuteDataTable(@"SELECT TOP 1 b.BillId, b.UnitsConsumed, b.Amount, b.BillingMonth, b.IsPaid, c.ConsumerNumber 
                                                 FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId
                                                 WHERE c.UserId=@uid ORDER BY b.BillingMonth DESC", new System.Data.SqlClient.SqlParameter("@uid", userId));
            if (dt.Rows.Count > 0)
            {
                var row = dt.Rows[0];
                litLatest.Text = $@"<div>Month: {Convert.ToDateTime(row[""BillingMonth""]).ToString("MMMM yyyy")} - Units: {row[""UnitsConsumed""]} - Amount: ₹{row[""Amount""]} - Status: {(Convert.ToBoolean(row[""IsPaid""]) ? "Paid":"Unpaid")} <a href='/User/BillReceipt.aspx?billId={row[""BillId""]}' class='btn btn-sm btn-primary'>View / Download</a></div>";
            }
            else litLatest.Text = "<div>No bills found.</div>";

            // prepare chart data (last 6 months)
            var dt2 = SqlHelper.ExecuteDataTable(@"SELECT TOP 6 b.BillingMonth, SUM(b.UnitsConsumed) Units FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId WHERE c.UserId=@uid GROUP BY b.BillingMonth ORDER BY b.BillingMonth DESC", new System.Data.SqlClient.SqlParameter("@uid", userId));
            var months = new System.Collections.Generic.List<string>();
            var units = new System.Collections.Generic.List<int>();
            foreach (System.Data.DataRow r in dt2.Rows)
            {
                months.Add(Convert.ToDateTime(r[""BillingMonth""]).ToString("MMM yy"));
                units.Add(Convert.ToInt32(r[""Units""]));
            }
            months.Reverse(); units.Reverse();
            var ms = Newtonsoft.Json.JsonConvert.SerializeObject(months);
            var us = Newtonsoft.Json.JsonConvert.SerializeObject(units);
            ltChartData.Text = $@"<script>
                var ctx = document.getElementById('consumptionChart').getContext('2d');
                new Chart(ctx, {{ type: 'bar', data: {{ labels: {ms}, datasets: [{{ label: 'Units', data: {us} }}] }}, options: {{ responsive:true }} }});
                </script>";
        }
        catch (Exception ex) { lblMsg.Text = ex.Message; }
    }
}