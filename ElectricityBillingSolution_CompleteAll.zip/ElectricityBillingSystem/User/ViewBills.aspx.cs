using System;
using System.Data;
using DBHelperLib;

public partial class User_ViewBills : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null) Response.Redirect("/Account/Login.aspx");
        if (!IsPostBack) LoadBills();
    }

    private void LoadBills()
    {
        int uid = Convert.ToInt32(Session["UserId"]);
        var dt = SqlHelper.ExecuteDataTable(@"SELECT b.BillId, b.BillingMonth, b.UnitsConsumed, b.Amount, b.IsPaid FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId WHERE c.UserId=@uid ORDER BY b.BillingMonth DESC", new System.Data.SqlClient.SqlParameter("@uid", uid));
        gvBills.DataSource = dt;
        gvBills.DataBind();
    }

    protected void gvBills_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        int billId = Convert.ToInt32(gvBills.DataKeys[rowIndex].Value);
        if (e.CommandName == "Download")
        {
            Response.Redirect($"/User/BillReceipt.aspx?billId={billId}");
        }
        else if (e.CommandName == "Pay")
        {
            Response.Redirect($"/User/QRPayment.aspx?billId={billId}&amount=800"); // simulate with amount
        }
    }
}