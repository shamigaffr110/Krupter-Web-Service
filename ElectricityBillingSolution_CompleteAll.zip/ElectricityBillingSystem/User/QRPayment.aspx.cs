using System;
using DBHelperLib;
using System.Data.SqlClient;

public partial class User_QRPayment : System.Web.UI.Page
{
    protected int billId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        int.TryParse(Request.QueryString["billId"], out billId);
    }

    protected void btnSimulate_Click(object sender, EventArgs e)
    {
        // mark bill as paid - simulation
        if (billId > 0)
        {
            SqlHelper.ExecuteNonQuery("UPDATE Bills SET IsPaid=1 WHERE BillId=@id", new SqlParameter("@id", billId));
            // insert payment record
            SqlHelper.ExecuteNonQuery("INSERT INTO Payments (BillId, AmountPaid, TransactionRef) VALUES (@b,@amt,@tx)",
                new SqlParameter("@b", billId),
                new SqlParameter("@amt", 800), // sample amount
                new SqlParameter("@tx", "QR_SIM_" + Guid.NewGuid().ToString().Substring(0,8)));
            lblMsg.Text = "Payment simulated and recorded.";
        }
        else lblMsg.Text = "No bill specified.";
    }
}