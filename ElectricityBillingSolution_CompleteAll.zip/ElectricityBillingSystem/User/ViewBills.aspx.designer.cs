public partial class User_ViewBills {
    protected global::System.Web.UI.WebControls.Label lblMsg;
    protected global::System.Web.UI.WebControls.GridView gvBills;
}