using System;
using DBHelperLib;

public partial class Concerns_Raise : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { if (Session["UserId"]==null) Response.Redirect("/Account/Login.aspx"); }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        SqlHelper.ExecuteNonQuery("INSERT INTO Concerns(UserId, Subject, Message, Status, CreatedOn) VALUES (@uid,@s,@m,'Open',GETDATE())",
            new System.Data.SqlClient.SqlParameter("@uid", Convert.ToInt32(Session["UserId"])),
            new System.Data.SqlClient.SqlParameter("@s", txtSub.Text.Trim()),
            new System.Data.SqlClient.SqlParameter("@m", txtMsgText.Text.Trim())
        );
        lblMsg.Text = "Concern submitted.";
    }
}