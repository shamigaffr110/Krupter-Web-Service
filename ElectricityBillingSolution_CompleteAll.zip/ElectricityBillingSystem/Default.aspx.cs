using System;
using System.Data;
using System.Data.SqlClient;
using DBHelperLib;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadNotices();
    }

    private void LoadNotices()
    {
        try
        {
            var dt = DBHelperLib.SqlHelper.ExecuteDataTable("SELECT TOP 5 Title, Message, CreatedOn FROM Notices ORDER BY CreatedOn DESC");
            rptNotices.DataSource = dt;
            rptNotices.DataBind();
        }
        catch (Exception ex) { /* ignore for now */ }
    }
}