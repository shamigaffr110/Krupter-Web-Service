using System;
public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Context.User?.Identity?.IsAuthenticated == true)
        {
            var name = Context.User.Identity.Name;
            var lbl = this.FindControl("lblUser") as System.Web.UI.WebControls.Label;
            if (lbl != null) lbl.Text = name;
        }
    }
}