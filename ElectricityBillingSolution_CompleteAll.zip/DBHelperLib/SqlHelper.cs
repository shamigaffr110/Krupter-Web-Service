using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DBHelperLib
{
    public static class SqlHelper
    {
        private static string ConnStr
        {
            get
            {
                // Read connection string named "EBillDB" from the host app web.config
                var cs = ConfigurationManager.ConnectionStrings["EBillDB"];
                if (cs == null) throw new Exception("Connection string 'EBillDB' not found in config.");
                return cs.ConnectionString;
            }
        }

        public static DataTable ExecuteDataTable(string sql, params SqlParameter[] parms)
        {
            using (var conn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                if (parms != null) cmd.Parameters.AddRange(parms);
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static int ExecuteNonQuery(string sql, params SqlParameter[] parms)
        {
            using (var conn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parms != null) cmd.Parameters.AddRange(parms);
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string sql, params SqlParameter[] parms)
        {
            using (var conn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parms != null) cmd.Parameters.AddRange(parms);
                conn.Open();
                return cmd.ExecuteScalar();
            }
        }
    }
}