using System.Data.SqlClient;

namespace RailwayReservation
{
    public static class DatabaseConnection
    {
        private static SqlConnection con;

        public static SqlConnection getConnection()
        {
            con = new SqlConnection(""); // Put your connection string here
            con.Open();
            return con;
        }
    }
}
