Railway Reservation v7

Run SQL/schema.sql, open solution in Visual Studio, update connection string in DatabaseConnection.cs and build.