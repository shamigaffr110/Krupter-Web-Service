using System;
namespace RailwayReservation.Exceptions
{
    public class BookingNotFoundException : ApplicationException
    {
        public BookingNotFoundException(int bookingId) : base($"Booking with id {bookingId} was not found.") {}
    }
}