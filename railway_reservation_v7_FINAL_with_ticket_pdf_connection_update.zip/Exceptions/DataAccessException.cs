using System;
namespace RailwayReservation.Exceptions
{
    public class DataAccessException : ApplicationException
    {
        public DataAccessException(string message, Exception inner) : base(message, inner) {}
    }
}