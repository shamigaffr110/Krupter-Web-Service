-- FULL RESET + SEED (generated 2025-08-13)
-- Drop existing tables (order matters due to FKs)
IF OBJECT_ID('dbo.Cancellations', 'U') IS NOT NULL DROP TABLE dbo.Cancellations;
IF OBJECT_ID('dbo.Refunds', 'U') IS NOT NULL DROP TABLE dbo.Refunds;
IF OBJECT_ID('dbo.Reservations', 'U') IS NOT NULL DROP TABLE dbo.Reservations;
IF OBJECT_ID('dbo.TrainClasses', 'U') IS NOT NULL DROP TABLE dbo.TrainClasses;
IF OBJECT_ID('dbo.TrainMaster', 'U') IS NOT NULL DROP TABLE dbo.TrainMaster;
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;
IF OBJECT_ID('dbo.Admins', 'U') IS NOT NULL DROP TABLE dbo.Admins;

-- Core tables
CREATE TABLE Admins (
    AdminId INT IDENTITY(1,1) PRIMARY KEY,
    AdminUsername VARCHAR(50) NOT NULL,
    AdminPassword VARCHAR(50) NOT NULL
);

CREATE TABLE Customers (
    CustId INT IDENTITY(1,1) PRIMARY KEY,
    CustName VARCHAR(100) NOT NULL,
    CustPhone VARCHAR(15) NOT NULL,
    CustEmail VARCHAR(100) NOT NULL,
    CustPassword VARCHAR(50) NOT NULL,
    RegistrationDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_Customers_Phone UNIQUE (CustPhone),
    CONSTRAINT UQ_Customers_Email UNIQUE (CustEmail)

);

CREATE TABLE TrainMaster (
    TrainNumber INT PRIMARY KEY,
    TrainName VARCHAR(100) NOT NULL,
    Source VARCHAR(50) NOT NULL,
    Destination VARCHAR(50) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1

);

-- Composite key (TrainNumber, ClassType); no TrainClassId
CREATE TABLE TrainClasses (
    TrainNumber INT NOT NULL,
    ClassType VARCHAR(20) NOT NULL, -- 'Sleeper', '3rd AC', '2nd AC'
    AvailableSeats INT NOT NULL,
    MaxSeats INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    CONSTRAINT PK_TrainClasses PRIMARY KEY (TrainNumber, ClassType),
    CONSTRAINT FK_TrainClasses_TrainMaster FOREIGN KEY (TrainNumber) REFERENCES TrainMaster(TrainNumber)
);

CREATE TABLE Reservations (
    BookingId INT IDENTITY(1,1) PRIMARY KEY,
    CustId INT NOT NULL,
    TrainNumber INT NOT NULL,
    ClassType VARCHAR(20) NOT NULL,
    TravelDate DATE NOT NULL,
    CurrentStatus VARCHAR(20) NOT NULL DEFAULT 'Confirmed',
    BookingDate DATETIME NOT NULL DEFAULT GETDATE(),
    Passengers INT NOT NULL DEFAULT 1,
    Amount DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_Reservations_Customers FOREIGN KEY (CustId) REFERENCES Customers(CustId),
    CONSTRAINT FK_Reservations_TrainClasses FOREIGN KEY (TrainNumber, ClassType) REFERENCES TrainClasses(TrainNumber, ClassType)
);

CREATE TABLE Cancellations (
    CancellationId INT IDENTITY(1,1) PRIMARY KEY,
    BookingId INT NOT NULL,
    CancelledAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Cancellations_Reservations FOREIGN KEY (BookingId) REFERENCES Reservations(BookingId)
);

CREATE TABLE Refunds (
    RefundId INT IDENTITY(1,1) PRIMARY KEY,
    BookingId INT NOT NULL,
    RefundAmount DECIMAL(10,2) NOT NULL,
    RefundedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Refunds_Reservations FOREIGN KEY (BookingId) REFERENCES Reservations(BookingId)
);

-- Triggers to adjust availability by Passengers
IF OBJECT_ID('trg_Reserve_Decrement', 'TR') IS NOT NULL DROP TRIGGER trg_Reserve_Decrement;
GO
CREATE TRIGGER trg_Reserve_Decrement ON Reservations
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE tc
    SET AvailableSeats = CASE 
        WHEN AvailableSeats - i.Passengers >= 0 THEN AvailableSeats - i.Passengers 
        ELSE AvailableSeats 
    END
    FROM TrainClasses tc
    INNER JOIN inserted i 
        ON tc.TrainNumber = i.TrainNumber AND tc.ClassType = i.ClassType;
END;
GO

IF OBJECT_ID('trg_Cancel_Increment', 'TR') IS NOT NULL DROP TRIGGER trg_Cancel_Increment;
GO
CREATE TRIGGER trg_Cancel_Increment ON Cancellations
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE tc
    SET AvailableSeats = CASE 
        WHEN AvailableSeats + r.Passengers <= tc.MaxSeats THEN AvailableSeats + r.Passengers 
        ELSE tc.MaxSeats 
    END
    FROM TrainClasses tc
    INNER JOIN Reservations r ON r.BookingId = inserted.BookingId
    INNER JOIN inserted ON 1=1
    WHERE tc.TrainNumber = r.TrainNumber AND tc.ClassType = r.ClassType;
END;
GO

-- Minimal seed data
INSERT INTO Admins (AdminUsername, AdminPassword) VALUES ('admin','admin123');

INSERT INTO Customers (CustName, CustPhone, CustEmail, CustPassword) VALUES
('John Doe','9876543210','john@example.com','pass123'),
('Asha Singh','9012345678','asha@example.com','pass456');

-- Trains (3 routes + returns)
-- 1) Bokaro Steel City (BKSC) ↔ New Delhi (NDLS)
INSERT INTO TrainMaster (TrainNumber, TrainName, Source, Destination) VALUES
(12801, 'Bokaro - New Delhi Express', 'Bokaro Steel City', 'New Delhi'),
(12802, 'New Delhi - Bokaro Express', 'New Delhi', 'Bokaro Steel City');

-- 2) Patna Jn (PNBE) ↔ Ranchi (RNC)
INSERT INTO TrainMaster (TrainNumber, TrainName, Source, Destination) VALUES
(18625, 'Patna - Ranchi Intercity', 'Patna Jn', 'Ranchi'),
(18626, 'Ranchi - Patna Intercity', 'Ranchi', 'Patna Jn');

-- 3) Jammu Tawi (JAT) ↔ New Delhi (NDLS)
INSERT INTO TrainMaster (TrainNumber, TrainName, Source, Destination) VALUES
(12426, 'Jammu Tawi - New Delhi Rajdhani', 'Jammu Tawi', 'New Delhi'),
(12425, 'New Delhi - Jammu Tawi Rajdhani', 'New Delhi', 'Jammu Tawi');

-- Classes for each train: Sleeper, 3rd AC, 2nd AC (no empties)
-- Seat & price assumptions: long distance > medium > short
-- BKSC–NDLS (long)
INSERT INTO TrainClasses (TrainNumber, ClassType, AvailableSeats, MaxSeats, Price) VALUES
(12801,'Sleeper',240,240,450.00),
(12801,'3rd AC',120,120,1050.00),
(12801,'2nd AC',72,72,1650.00),
(12802,'Sleeper',240,240,450.00),
(12802,'3rd AC',120,120,1050.00),
(12802,'2nd AC',72,72,1650.00);

-- PNBE–RNC (short/medium)
INSERT INTO TrainClasses (TrainNumber, ClassType, AvailableSeats, MaxSeats, Price) VALUES
(18625,'Sleeper',180,180,220.00),
(18625,'3rd AC',90,90,520.00),
(18625,'2nd AC',54,54,780.00),
(18626,'Sleeper',180,180,220.00),
(18626,'3rd AC',90,90,520.00),
(18626,'2nd AC',54,54,780.00);

-- JAT–NDLS (long)
INSERT INTO TrainClasses (TrainNumber, ClassType, AvailableSeats, MaxSeats, Price) VALUES
(12426,'Sleeper',210,210,600.00),
(12426,'3rd AC',110,110,1350.00),
(12426,'2nd AC',66,66,2100.00),
(12425,'Sleeper',210,210,600.00),
(12425,'3rd AC',110,110,1350.00),
(12425,'2nd AC',66,66,2100.00);

-- Sample bookings to test availability & PNR
DECLARE @today DATE = CAST(GETDATE() AS DATE);

-- John books 3 Sleeper seats BKSC -> NDLS
INSERT INTO Reservations (CustId, TrainNumber, ClassType, TravelDate, Passengers, Amount)
VALUES (1, 12801, 'Sleeper', @today, 3, 3 * 450.00);

-- Asha books 2 3rd AC seats Patna -> Ranchi
INSERT INTO Reservations (CustId, TrainNumber, ClassType, TravelDate, Passengers, Amount)
VALUES (2, 18625, '3rd AC', DATEADD(DAY, 1, @today), 2, 2 * 520.00);