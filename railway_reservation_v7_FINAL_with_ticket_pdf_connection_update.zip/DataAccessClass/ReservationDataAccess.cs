using System;
using System.Data.SqlClient;

namespace RailwayReservation.DataAccessClass
{
    public class ReservationDataAccess
    {
        public int Book(int custId, int trainClassId, DateTime travelDate)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                // check availability
                var chk = new SqlCommand("SELECT AvailableSeats, Price FROM TrainClasses WHERE TrainClassId=@id", conn);
                chk.Parameters.AddWithValue("@id", trainClassId);
                var rd = chk.ExecuteReader();
                if (!rd.Read()) { rd.Close(); return 0; }
                int av = Convert.ToInt32(rd["AvailableSeats"]);
                decimal price = Convert.ToDecimal(rd["Price"]);
                rd.Close();
                if (av <= 0) return 0;

                var ins = new SqlCommand("INSERT INTO Reservations (CustId,TrainClassId,TravelDate,CurrentStatus,BookingDate,Amount) VALUES(@c,@tc,@d,'Confirmed',GETDATE(),@amt); SELECT CAST(SCOPE_IDENTITY() AS INT);", conn);
                ins.Parameters.AddWithValue("@c", custId);
                ins.Parameters.AddWithValue("@tc", trainClassId);
                ins.Parameters.AddWithValue("@d", travelDate);
                ins.Parameters.AddWithValue("@amt", price);
                var obj = ins.ExecuteScalar();
                return obj != null ? (int)obj : 0;
            }
        }
    }

        
        public int BookWithPassengers(int custId, int trainNumber, string classType, DateTime travelDate, int passengers)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                // Get price and availability
                var chk = new SqlCommand("SELECT AvailableSeats, Price FROM TrainClasses WHERE TrainNumber=@tn AND ClassType=@ct", conn);
                chk.Parameters.AddWithValue("@tn", trainNumber);
                chk.Parameters.AddWithValue("@ct", classType);
                var rd = chk.ExecuteReader();
                if (!rd.Read()) { rd.Close(); return 0; }
                int av = Convert.ToInt32(rd["AvailableSeats"]);
                decimal price = Convert.ToDecimal(rd["Price"]);
                rd.Close();
                if (av < passengers || passengers <= 0) return 0;

                decimal total = price * passengers;

                var ins = new SqlCommand(@"
INSERT INTO Reservations (CustId, TrainNumber, ClassType, TravelDate, CurrentStatus, BookingDate, Passengers, Amount) 
VALUES (@c,@tn,@ct,@d,'Confirmed',GETDATE(),@p,@amt); 
SELECT CAST(SCOPE_IDENTITY() AS INT);", conn);
                ins.Parameters.AddWithValue("@c", custId);
                ins.Parameters.AddWithValue("@tn", trainNumber);
                ins.Parameters.AddWithValue("@ct", classType);
                ins.Parameters.AddWithValue("@d", travelDate);
                ins.Parameters.AddWithValue("@p", passengers);
                ins.Parameters.AddWithValue("@amt", total);
                var obj = ins.ExecuteScalar();
                return obj != null ? (int)obj : 0;
            }
        }
    
        
        public (bool Success, decimal Refund) CancelBookingByUser(int bookingId, out string message)
        {
            message = "";
            using (SqlConnection conn = DatabaseConnection.getConnection())
            using (SqlTransaction tx = conn.BeginTransaction())
            {
                try
                {
                    var get = new SqlCommand("SELECT BookingId, TravelDate, Amount FROM Reservations WHERE BookingId=@b", conn, tx);
                    get.Parameters.AddWithValue("@b", bookingId);
                    var rd = get.ExecuteReader();
                    if (!rd.Read()) { rd.Close(); tx.Rollback(); message = "Booking not found."; return (false, 0m); }
                    DateTime travel = Convert.ToDateTime(rd["TravelDate"]);
                    decimal amount = Convert.ToDecimal(rd["Amount"]);
                    rd.Close();

                    if (travel.Date < DateTime.Today)
                    {
                        tx.Rollback();
                        message = "Cannot cancel past-date booking.";
                        return (false, 0m);
                    }

                    double hours = (travel - DateTime.Today).TotalHours;
                    decimal refundPct = 0m;
                    if (hours >= 48) refundPct = 1.0m;
                    else if (hours >= 24) refundPct = 0.5m;
                    else refundPct = 0m;

                    decimal refund = Math.Round(amount * refundPct, 2);

                    var insC = new SqlCommand("INSERT INTO Cancellations (BookingId, CancellationReason) VALUES (@b, @r);", conn, tx);
                    insC.Parameters.AddWithValue("@b", bookingId);
                    insC.Parameters.AddWithValue("@r", "User requested cancellation");
                    insC.ExecuteNonQuery();

                    if (refund > 0)
                    {
                        var insR = new SqlCommand("INSERT INTO Refunds (BookingId, RefundAmount) VALUES (@b,@amt);", conn, tx);
                        insR.Parameters.AddWithValue("@b", bookingId);
                        insR.Parameters.AddWithValue("@amt", refund);
                        insR.ExecuteNonQuery();
                    }

                    tx.Commit();
                    message = "Cancellation completed.";
                    return (true, refund);
                }
                catch (System.Exception ex)
                {
                    tx.Rollback();
                    throw new RailwayReservation.Exceptions.DataAccessException("Failed to cancel booking.", ex);
                }
            }
        }

        public (bool Success, decimal Refund) CancelBookingByAdmin(int bookingId, string reason)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            using (SqlTransaction tx = conn.BeginTransaction())
            {
                try
                {
                    var get = new SqlCommand("SELECT BookingId, Amount FROM Reservations WHERE BookingId=@b", conn, tx);
                    get.Parameters.AddWithValue("@b", bookingId);
                    var rd = get.ExecuteReader();
                    if (!rd.Read()) { rd.Close(); tx.Rollback(); return (false, 0m); }
                    decimal amount = Convert.ToDecimal(rd["Amount"]);
                    rd.Close();

                    var insC = new SqlCommand("INSERT INTO Cancellations (BookingId, CancellationReason) VALUES (@b,@r);", conn, tx);
                    insC.Parameters.AddWithValue("@b", bookingId);
                    insC.Parameters.AddWithValue("@r", string.IsNullOrWhiteSpace(reason) ? "Admin cancellation" : reason);
                    insC.ExecuteNonQuery();

                    var insR = new SqlCommand("INSERT INTO Refunds (BookingId, RefundAmount) VALUES (@b,@amt);", conn, tx);
                    insR.Parameters.AddWithValue("@b", bookingId);
                    insR.Parameters.AddWithValue("@amt", amount);
                    insR.ExecuteNonQuery();

                    tx.Commit();
                    return (true, amount);
                }
                catch (System.Exception ex)
                {
                    tx.Rollback();
                    throw new RailwayReservation.Exceptions.DataAccessException("Failed to cancel booking by admin.", ex);
                }
            }
        }

        public System.Data.DataTable GetAllBookings()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT r.BookingId, c.CustName, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount, r.CurrentStatus, r.BookingDate
FROM Reservations r
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
ORDER BY r.BookingDate DESC", conn);
                var dt = new System.Data.DataTable();
                da.Fill(dt); return dt;
            }
        }

        public System.Data.DataTable GetAllCancellations()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT k.CancellationId, k.BookingId, c.CustName, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount, k.CancelledAt, k.CancellationReason
FROM Cancellations k
JOIN Reservations r ON k.BookingId=r.BookingId
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
ORDER BY k.CancelledAt DESC", conn);
                var dt = new System.Data.DataTable();
                da.Fill(dt); return dt;
            }
        }

        public (decimal TotalSales, decimal TotalRefunds, decimal NetRevenue) GetRevenueSummary()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                decimal sales = 0, refunds = 0;
                var cmd1 = new SqlCommand("SELECT ISNULL(SUM(Amount),0) FROM Reservations", conn);
                sales = Convert.ToDecimal(cmd1.ExecuteScalar());
                var cmd2 = new SqlCommand("SELECT ISNULL(SUM(RefundAmount),0) FROM Refunds", conn);
                refunds = Convert.ToDecimal(cmd2.ExecuteScalar());
                return (sales, refunds, sales - refunds);
            }
        }

        public System.Data.DataTable GetBookingsByCustomer(string keyword)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT r.BookingId, c.CustName, c.CustPhone, c.CustEmail, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount
FROM Reservations r
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
WHERE c.CustName LIKE @k OR c.CustPhone LIKE @k OR c.CustEmail LIKE @k
ORDER BY r.TravelDate DESC", conn);
                da.SelectCommand.Parameters.AddWithValue("@k", "%" + keyword + "%");
                var dt = new System.Data.DataTable();
                da.Fill(dt); return dt;
            }
        }
    }
