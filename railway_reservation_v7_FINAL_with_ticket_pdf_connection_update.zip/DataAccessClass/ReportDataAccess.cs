
using System;
using System.Data;
using System.Data.SqlClient;

namespace RailwayReservation.DataAccessClass
{
    public class ReportDataAccess
    {
        public DataTable GetAllBookings()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT r.BookingId, c.CustName, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount, r.BookingDate
FROM Reservations r
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
ORDER BY r.BookingDate DESC", conn);
                var dt = new DataTable(); da.Fill(dt); return dt;
            }
        }
        public DataTable GetAllCancellations()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT k.CancellationId, k.BookingId, c.CustName, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount, k.CancelledAt, k.CancellationReason
FROM Cancellations k
JOIN Reservations r ON k.BookingId=r.BookingId
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
ORDER BY k.CancelledAt DESC", conn);
                var dt = new DataTable(); da.Fill(dt); return dt;
            }
        }
        public (decimal TotalSales, decimal TotalRefunds, decimal NetRevenue) GetRevenueSummary()
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                decimal sales = 0, refunds = 0;
                var cmd1 = new SqlCommand("SELECT ISNULL(SUM(Amount),0) FROM Reservations", conn);
                sales = Convert.ToDecimal(cmd1.ExecuteScalar());
                var cmd2 = new SqlCommand("SELECT ISNULL(SUM(RefundAmount),0) FROM Refunds", conn);
                refunds = Convert.ToDecimal(cmd2.ExecuteScalar());
                return (sales, refunds, sales - refunds);
            }
        }
        public DataTable GetBookingsByCustomer(string keyword)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var da = new SqlDataAdapter(@"
SELECT r.BookingId, c.CustName, c.CustPhone, c.CustEmail, t.TrainName, r.ClassType, r.TravelDate, r.Passengers, r.Amount
FROM Reservations r
JOIN Customers c ON r.CustId=c.CustId
JOIN TrainMaster t ON r.TrainNumber=t.TrainNumber
WHERE c.CustName LIKE @k OR c.CustPhone LIKE @k OR c.CustEmail LIKE @k
ORDER BY r.TravelDate DESC", conn);
                da.SelectCommand.Parameters.AddWithValue("@k", "%" + keyword + "%");
                var dt = new DataTable(); da.Fill(dt); return dt;
            }
        }
    }
}
