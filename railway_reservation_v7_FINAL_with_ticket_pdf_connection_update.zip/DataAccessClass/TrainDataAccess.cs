using System.Collections.Generic;
using System.Data.SqlClient;
using RailwayReservation.Models;
using System;

namespace RailwayReservation.DataAccessClass
{
    public class TrainDataAccess
    {
        public List<TrainMaster> GetAllTrains()
        {
            var list = new List<TrainMaster>();
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("SELECT TrainNumber,TrainName,Source,Destination FROM TrainMaster", conn);
                var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    list.Add(new TrainMaster
                    {
                        TrainNumber = Convert.ToInt32(rd["TrainNumber"]),
                        TrainName = rd["TrainName"].ToString(),
                        Source = rd["Source"].ToString(),
                        Destination = rd["Destination"].ToString()
                    });
                }
            }
            return list;
        }

        public List<TrainClass> GetClassesForTrain(int trainNumber)
        {
            var list = new List<TrainClass>();
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("SELECT TrainClassId,TrainNumber,ClassType,AvailableSeats,MaxSeats,Price FROM TrainClasses WHERE TrainNumber=@tn", conn);
                cmd.Parameters.AddWithValue("@tn", trainNumber);
                var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    list.Add(new TrainClass
                    {
                        TrainNumber = Convert.ToInt32(rd["TrainNumber"]),
                        ClassType = rd["ClassType"].ToString(),
                        AvailableSeats = Convert.ToInt32(rd["AvailableSeats"]),
                        MaxSeats = Convert.ToInt32(rd["MaxSeats"]),
                        Price = Convert.ToDecimal(rd["Price"]) 
                    });
                }
            }
            return list;
        }
    }

        
        public System.Data.DataTable GetAllTrainsWithAvailability(bool includeInactive=false)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                string sql = @"
SELECT tm.TrainNumber, tm.TrainName, tm.Source, tm.Destination, tm.IsActive,
SUM(CASE WHEN tc.ClassType='Sleeper' THEN tc.AvailableSeats ELSE 0 END) AS SleeperAvailable,
SUM(CASE WHEN tc.ClassType='3rd AC' THEN tc.AvailableSeats ELSE 0 END) AS ThirdACAvailable,
SUM(CASE WHEN tc.ClassType='2nd AC' THEN tc.AvailableSeats ELSE 0 END) AS SecondACAvailable
FROM TrainMaster tm
LEFT JOIN TrainClasses tc ON tm.TrainNumber=tc.TrainNumber
WHERE (@all=1 OR tm.IsActive=1)
GROUP BY tm.TrainNumber, tm.TrainName, tm.Source, tm.Destination, tm.IsActive
ORDER BY tm.TrainNumber;";
                var da = new SqlDataAdapter(sql, conn);
                da.SelectCommand.Parameters.AddWithValue("@all", includeInactive?1:0);
                var dt = new System.Data.DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public int AddTrain(int trainNumber, string trainName, string source, string destination, 
                            int sleeperSeats, decimal sleeperPrice, 
                            int thirdAcSeats, decimal thirdAcPrice,
                            int secondAcSeats, decimal secondAcPrice)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            using (SqlTransaction tx = conn.BeginTransaction())
            {
                try
                {
                    var insTrain = new SqlCommand("INSERT INTO TrainMaster (TrainNumber,TrainName,Source,Destination,IsActive) VALUES (@n,@name,@src,@dst,1);", conn, tx);
                    insTrain.Parameters.AddWithValue("@n", trainNumber);
                    insTrain.Parameters.AddWithValue("@name", trainName);
                    insTrain.Parameters.AddWithValue("@src", source);
                    insTrain.Parameters.AddWithValue("@dst", destination);
                    insTrain.ExecuteNonQuery();

                    var insTC = new SqlCommand(@"
INSERT INTO TrainClasses (TrainNumber,ClassType,AvailableSeats,MaxSeats,Price) VALUES
(@n,'Sleeper',@sSleeper,@sSleeper,@pSleeper),
(@n,'3rd AC',@sThird,@sThird,@pThird),
(@n,'2nd AC',@sSecond,@sSecond,@pSecond);", conn, tx);
                    insTC.Parameters.AddWithValue("@n", trainNumber);
                    insTC.Parameters.AddWithValue("@sSleeper", sleeperSeats);
                    insTC.Parameters.AddWithValue("@pSleeper", sleeperPrice);
                    insTC.Parameters.AddWithValue("@sThird", thirdAcSeats);
                    insTC.Parameters.AddWithValue("@pThird", thirdAcPrice);
                    insTC.Parameters.AddWithValue("@sSecond", secondAcSeats);
                    insTC.Parameters.AddWithValue("@pSecond", secondAcPrice);
                    insTC.ExecuteNonQuery();

                    tx.Commit();
                    return 1;
                }
                catch (System.Exception ex)
                {
                    tx.Rollback();
                    throw new RailwayReservation.Exceptions.DataAccessException("Failed to add train.", ex);
                }
            }
        }

        public int SetTrainActiveStatus(int trainNumber, bool isActive)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("UPDATE TrainMaster SET IsActive=@a WHERE TrainNumber=@n;", conn);
                cmd.Parameters.AddWithValue("@a", isActive?1:0);
                cmd.Parameters.AddWithValue("@n", trainNumber);
                return cmd.ExecuteNonQuery();
            }
        }
    }
