Deployment notes:
- Target .NET Framework 4.7.2. Use App Pool v4.0 CLR in IIS.
- Give app pool identity access to the site folder and optionally to the uploads folder.
- Configure SMTP properly in Web.config to enable email sending.
- For production PDF generation ensure iTextSharp license compatibility.
