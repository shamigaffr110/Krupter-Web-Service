# ElectricityBillSuite - Adani-inspired UI (Full ZIP)
Generated: 2025-08-24T18:37:24.752778 UTC

This package is an ASP.NET Web Forms (Framework 4.7.2) project skeleton inspired by the Adani Electricity UI style.
It includes user/admin flows, payment QR/UPI simulation, iTextSharp-based legal notice generation, database schema, assets, ER diagram and flowchart.

**Important steps to run:**
1. Open `ElectricityBillSuite.sln` in Visual Studio (Windows).
2. In Package Manager Console run: `Install-Package iTextSharp -Version 5.5.13.3`
3. Create SQL Server DB `EbDb` and run `Database/schema.sql` and `Database/sample_data.sql`.
4. Update connection string and SMTP settings in `ElectricityBillSuite.Web/Web.config`.
5. Build and run the Web project (IIS Express).

Provided pages (high level): Home, Account (register/login), User (dashboard, bills, payment, new connection, concerns, profile, transactions), Admin (dashboard, manage connections, generate bills, revenue, legal notices).

Assets include: logo.png, hero.jpg, er_diagram.png, flowchart.png, user_sample.jpg
