INSERT INTO Admins(Name,Email,PasswordHash) VALUES('Super Admin','admin@example.com','admin123');
INSERT INTO Users(Name,Phone,Email,Dob,PasswordHash) VALUES('Asha Devi','9876543210','asha@example.com','1990-03-21','pass123'),('Rakesh Kumar','9876501234','rakesh@example.com','1987-07-12','pass123');
INSERT INTO Connections(UserID,ConsumerNo,Address,Locality,Type,Load,Status) VALUES(1,'CNS1001','MG Road','Ranchi','Urban',5.0,'Active'),(2,'CNS1002','Main Road','Dhanbad','Urban',3.5,'Pending');
INSERT INTO Bills(UserID,ConsumerNo,UnitsConsumed,Amount,BillDate,IsPaid) VALUES(1,'CNS1001',250,1875,'2024-12-10',0),(1,'CNS1001',300,2250,'2025-01-10',1),(2,'CNS1002',200,1500,'2025-01-08',0);
