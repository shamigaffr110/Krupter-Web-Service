$(function(){
  console.log('ElectricityBillSuite UI ready');
});
function showToast(msg){var el = $('<div class="toast align-items-center text-white bg-dark border-0" role="alert" aria-live="assertive" aria-atomic="true"><div class="d-flex"><div class="toast-body">'+msg+'</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>');$('body').append(el);var t = new bootstrap.Toast(el[0]);t.show();setTimeout(function(){el.remove();},5000);}