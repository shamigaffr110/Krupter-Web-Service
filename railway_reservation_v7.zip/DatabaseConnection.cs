using System.Data.SqlClient;

namespace RailwayReservation
{
    public static class DatabaseConnection
    {
        private static SqlConnection con;
        private static string connectionString = "Server=YOUR_SERVER;Database=RailwayDB;Trusted_Connection=True;";
        public static SqlConnection getConnection()
        {
            con = new SqlConnection(connectionString);
            con.Open();
            return con;
        }
    }
}
