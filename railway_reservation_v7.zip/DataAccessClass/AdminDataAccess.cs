using System;
using System.Data.SqlClient;

namespace RailwayReservation.DataAccessClass
{
    public class AdminDataAccess
    {
        public bool Login(string user, string pass)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("SELECT COUNT(*) FROM Admins WHERE AdminUsername=@u AND AdminPassword=@p", conn);
                cmd.Parameters.AddWithValue("@u", user);
                cmd.Parameters.AddWithValue("@p", pass);
                int c = (int)cmd.ExecuteScalar();
                return c > 0;
            }
        }

        public void DeleteBookingAndRefund(int bookingId)
        {
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                // compute refund and insert
                var cmd = new SqlCommand(@"SELECT r.BookingId, r.TrainClassId, r.TravelDate, r.Amount, r.CustId FROM Reservations r WHERE r.BookingId=@b", conn);
                cmd.Parameters.AddWithValue("@b", bookingId);
                var rd = cmd.ExecuteReader();
                if (!rd.Read()) { rd.Close(); return; }
                decimal amount = Convert.ToDecimal(rd[3]);
                int custId = Convert.ToInt32(rd[4]);
                rd.Close();

                // full refund
                var ins = new SqlCommand("INSERT INTO Refunds (BookingId,CustId,RefundAmount,Reason) VALUES(@b,@c,@r,'AdminDeletion')", conn);
                ins.Parameters.AddWithValue("@b", bookingId);
                ins.Parameters.AddWithValue("@c", custId);
                ins.Parameters.AddWithValue("@r", amount);
                ins.ExecuteNonQuery();

                var ic = new SqlCommand("INSERT INTO Cancellations (BookingId) VALUES(@b)", conn);
                ic.Parameters.AddWithValue("@b", bookingId);
                ic.ExecuteNonQuery();

                var upd = new SqlCommand("UPDATE Reservations SET CurrentStatus='Cancelled' WHERE BookingId=@b", conn);
                upd.Parameters.AddWithValue("@b", bookingId);
                upd.ExecuteNonQuery();
            }
        }
    }
}
