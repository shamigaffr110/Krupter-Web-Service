using System.Collections.Generic;
using System.Data.SqlClient;
using RailwayReservation.Models;
using System;

namespace RailwayReservation.DataAccessClass
{
    public class TrainDataAccess
    {
        public List<TrainMaster> GetAllTrains()
        {
            var list = new List<TrainMaster>();
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("SELECT TrainNumber,TrainName,Source,Destination FROM TrainMaster", conn);
                var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    list.Add(new TrainMaster
                    {
                        TrainNumber = Convert.ToInt32(rd["TrainNumber"]),
                        TrainName = rd["TrainName"].ToString(),
                        Source = rd["Source"].ToString(),
                        Destination = rd["Destination"].ToString()
                    });
                }
            }
            return list;
        }

        public List<TrainClass> GetClassesForTrain(int trainNumber)
        {
            var list = new List<TrainClass>();
            using (SqlConnection conn = DatabaseConnection.getConnection())
            {
                var cmd = new SqlCommand("SELECT TrainClassId,TrainNumber,ClassType,AvailableSeats,MaxSeats,Price FROM TrainClasses WHERE TrainNumber=@tn", conn);
                cmd.Parameters.AddWithValue("@tn", trainNumber);
                var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    list.Add(new TrainClass
                    {
                        TrainClassId = Convert.ToInt32(rd["TrainClassId"]),
                        TrainNumber = Convert.ToInt32(rd["TrainNumber"]),
                        ClassType = rd["ClassType"].ToString(),
                        AvailableSeats = Convert.ToInt32(rd["AvailableSeats"]),
                        MaxSeats = Convert.ToInt32(rd["MaxSeats"]),
                        Price = Convert.ToDecimal(rd["Price"]) 
                    });
                }
            }
            return list;
        }
    }
}
