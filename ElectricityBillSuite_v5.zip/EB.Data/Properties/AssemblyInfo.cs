using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("EB.Data")]
[assembly: AssemblyDescription("Beginner-style DB connection helper")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("EB.Data")]
[assembly: AssemblyCopyright("Copyright © 2025")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("8d1a8d1e-d9de-47b7-8d5f-1a9b4c27b55d")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
