
/* ElectricityBill Suite - SQL Server setup */
CREATE DATABASE ElectricityBillDB;
GO
USE ElectricityBillDB;
GO

IF OBJECT_ID('dbo.Users') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID('dbo.Admins') IS NOT NULL DROP TABLE dbo.Admins;
IF OBJECT_ID('dbo.ElectricityBill') IS NOT NULL DROP TABLE dbo.ElectricityBill;
IF OBJECT_ID('dbo.Connections') IS NOT NULL DROP TABLE dbo.Connections;
IF OBJECT_ID('dbo.Payments') IS NOT NULL DROP TABLE dbo.Payments;
IF OBJECT_ID('dbo.Concerns') IS NOT NULL DROP TABLE dbo.Concerns;
IF OBJECT_ID('dbo.Notices') IS NOT NULL DROP TABLE dbo.Notices;

CREATE TABLE Users(
  user_id INT IDENTITY PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  email VARCHAR(50) NOT NULL UNIQUE,
  dob DATE NULL,
  password VARCHAR(50) NOT NULL
);

CREATE TABLE Admins(
  admin_id INT IDENTITY PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(50) NOT NULL
);

CREATE TABLE ElectricityBill(
  consumer_number VARCHAR(20) PRIMARY KEY,
  consumer_name VARCHAR(50) NOT NULL,
  units_consumed INT NOT NULL,
  bill_amount FLOAT NOT NULL,
  bill_date DATETIME NOT NULL DEFAULT(GETDATE()),
  status VARCHAR(20) NOT NULL DEFAULT('Unpaid')
);

CREATE TABLE Connections(
  connection_id INT IDENTITY PRIMARY KEY,
  user_id INT NOT NULL REFERENCES Users(user_id),
  consumer_number VARCHAR(20) NULL,
  name VARCHAR(50),
  phone VARCHAR(15),
  email VARCHAR(50),
  address VARCHAR(100),
  locality VARCHAR(50),
  type VARCHAR(20),           -- Urban/Local
  load INT,                   -- kW
  connection_type VARCHAR(20),-- Single/Three
  id_proof_path VARCHAR(150),
  photo_path VARCHAR(150),
  status VARCHAR(20) NOT NULL DEFAULT('Pending'), -- Pending/Active/Inactive
  created_at DATETIME NOT NULL DEFAULT(GETDATE())
);

CREATE TABLE Payments(
  payment_id INT IDENTITY PRIMARY KEY,
  user_id INT NOT NULL REFERENCES Users(user_id),
  consumer_number VARCHAR(20) NOT NULL REFERENCES ElectricityBill(consumer_number),
  amount FLOAT NOT NULL,
  payment_date DATETIME NOT NULL DEFAULT(GETDATE()),
  method VARCHAR(20) NOT NULL, -- UPI/QR
  status VARCHAR(20) NOT NULL, -- Success/Failed
  txn_ref VARCHAR(50) NULL
);

CREATE TABLE Concerns(
  concern_id INT IDENTITY PRIMARY KEY,
  user_id INT NOT NULL REFERENCES Users(user_id),
  consumer_number VARCHAR(20) NULL,
  message VARCHAR(200) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT('Open'),
  created_at DATETIME NOT NULL DEFAULT(GETDATE()),
  resolved_at DATETIME NULL
);

CREATE TABLE Notices(
  notice_id INT IDENTITY PRIMARY KEY,
  consumer_number VARCHAR(20) NOT NULL,
  message VARCHAR(200) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT(GETDATE())
);

INSERT INTO Admins(username,password) VALUES('admin','12345');
