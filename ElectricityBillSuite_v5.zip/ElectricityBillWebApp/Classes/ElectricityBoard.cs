using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp.Classes
{
    public class ElectricityBoard
    {
        public void CalculateBill(ElectricityBill ebill)
        {
            int units = ebill.UnitsConsumed;
            double amount = 0;

            if (units <= 100) { amount = 0; }
            else if (units <= 300) { amount = (units - 100) * 1.5; }
            else if (units <= 600) { amount = (200 * 1.5) + ((units - 300) * 3.5); }
            else if (units <= 1000) { amount = (200 * 1.5) + (300 * 3.5) + ((units - 600) * 5.5); }
            else { amount = (200 * 1.5) + (300 * 3.5) + (400 * 5.5) + ((units - 1000) * 7.5); }

            ebill.BillAmount = amount;
        }

        public void AddBill(ElectricityBill ebill)
        {
            SqlConnection con = DBHandler.GetConnection();
            string sql = "INSERT INTO ElectricityBill(consumer_number,consumer_name,units_consumed,bill_amount,status) VALUES(@num,@name,@units,@amount,'Unpaid')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@num", ebill.ConsumerNumber);
            cmd.Parameters.AddWithValue("@name", ebill.ConsumerName);
            cmd.Parameters.AddWithValue("@units", ebill.UnitsConsumed);
            cmd.Parameters.AddWithValue("@amount", ebill.BillAmount);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<ElectricityBill> Generate_N_BillDetails(int num)
        {
            List<ElectricityBill> list = new List<ElectricityBill>();
            SqlConnection con = DBHandler.GetConnection();
            string sql = "SELECT TOP (@n) consumer_number, consumer_name, units_consumed, bill_amount FROM ElectricityBill ORDER BY bill_date DESC";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@n", num);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ElectricityBill eb = new ElectricityBill();
                eb.ConsumerNumber = dr["consumer_number"].ToString();
                eb.ConsumerName = dr["consumer_name"].ToString();
                eb.UnitsConsumed = Convert.ToInt32(dr["units_consumed"]);
                eb.BillAmount = Convert.ToDouble(dr["bill_amount"]);
                list.Add(eb);
            }
            con.Close();
            return list;
        }

        public bool IsValidConsumerNumber(string num)
        {
            // Must start with EB and have 5 digits
            if (string.IsNullOrEmpty(num)) return false;
            if (!num.StartsWith("EB")) return false;
            if (num.Length != 7) return false;
            int digits = 0;
            if (int.TryParse(num.Substring(2), out digits)) { return true; }
            return false;
        }
    }
}
