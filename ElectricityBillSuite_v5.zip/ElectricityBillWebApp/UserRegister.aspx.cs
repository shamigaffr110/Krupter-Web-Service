using System;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class UserRegister : System.Web.UI.Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = DBHandler.GetConnection();
                string q = "INSERT INTO Users(name,phone,email,dob,password) VALUES(@n,@p,@e,@d,@pw)";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@e", txtEmail.Text);
                DateTime d = DateTime.Now;
                DateTime.TryParse(txtDob.Text, out d);
                cmd.Parameters.AddWithValue("@d", d);
                cmd.Parameters.AddWithValue("@pw", txtPass.Text);
                con.Open(); cmd.ExecuteNonQuery(); con.Close();
                lblMsg.Text = "Registered. You can login now.";
            }
            catch (Exception ex)
            {
                lblMsg.Text = "Error: " + ex.Message;
            }
        }
    }
}
