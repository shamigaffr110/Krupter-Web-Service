using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class ConnectionsAdmin : System.Web.UI.Page
    {
        protected void btnLoad_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            SqlDataAdapter da = new SqlDataAdapter("SELECT TOP 50 connection_id,user_id,consumer_number,name,phone,email,address,locality,type,load,connection_type,status,created_at FROM Connections ORDER BY created_at DESC", con);
            DataTable dt = new DataTable(); da.Fill(dt);
            grid.DataSource = dt; grid.DataBind();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Connections SET consumer_number=@c,status=@s WHERE connection_id=@i", con);
            cmd.Parameters.AddWithValue("@c", txtConsumer.Text);
            cmd.Parameters.AddWithValue("@s", ddlStatus.SelectedValue);
            cmd.Parameters.AddWithValue("@i", Convert.ToInt32(txtConnId.Text));
            con.Open(); cmd.ExecuteNonQuery(); con.Close();
            btnLoad_Click(sender, e);
        }
    }
}
