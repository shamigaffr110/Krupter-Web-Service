using System;
using ElectricityBillWebApp.Classes;

namespace ElectricityBillWebApp
{
    public partial class ViewBills : System.Web.UI.Page
    {
        protected void btnGo_Click(object sender, EventArgs e)
        {
            int n = 5;
            int.TryParse(txtN.Text, out n);
            var eb = new ElectricityBoard();
            grid.DataSource = eb.Generate_N_BillDetails(n);
            grid.DataBind();
            lblMsg.Text = "Details of last '" + n + "' bills:";
        }
    }
}
