using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;
namespace ElectricityBillWebApp
{
    public partial class ConcernsAdmin : System.Web.UI.Page
    {
        protected void btnLoad_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            SqlDataAdapter da = new SqlDataAdapter("SELECT concern_id,user_id,consumer_number,message,status,created_at FROM Concerns ORDER BY created_at DESC", con);
            DataTable dt = new DataTable(); da.Fill(dt);
            grid.DataSource = dt; grid.DataBind();
        }
        protected void btnResolve_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Concerns SET status='Resolved', resolved_at=GETDATE() WHERE concern_id=@i", con);
            cmd.Parameters.AddWithValue("@i", Convert.ToInt32(txtId.Text));
            con.Open(); cmd.ExecuteNonQuery(); con.Close();
            btnLoad_Click(sender,e);
        }
    }
}
