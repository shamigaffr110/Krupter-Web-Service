using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;
namespace ElectricityBillWebApp
{
    public partial class CustomerSearch : System.Web.UI.Page
    {
        protected void btnFind_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM ElectricityBill WHERE consumer_number=@c", con);
            da.SelectCommand.Parameters.AddWithValue("@c", txtConsumer.Text);
            DataTable dt = new DataTable(); da.Fill(dt);
            grid.DataSource = dt; grid.DataBind();
        }
    }
}
