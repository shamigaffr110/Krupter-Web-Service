using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class Notices : System.Web.UI.Page
    {
        protected void btnFind_Click(object sender, EventArgs e)
        {
            // Criteria: unpaid for > 1 year and bill_amount > 200000
            SqlConnection con = DBHandler.GetConnection();
            string q = @"SELECT consumer_number, consumer_name, bill_amount, bill_date, status
                         FROM ElectricityBill
                         WHERE status='Unpaid' 
                           AND bill_amount > 200000 
                           AND DATEDIFF(day, bill_date, GETDATE()) > 365";
            SqlDataAdapter da = new SqlDataAdapter(q, con);
            DataTable dt = new DataTable(); da.Fill(dt);
            grid.DataSource = dt; grid.DataBind();
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string c = txtConsumer.Text;
                SqlConnection con = DBHandler.GetConnection();
                SqlCommand cmd = new SqlCommand("INSERT INTO Notices(consumer_number, message) VALUES(@c,@m)", con);
                cmd.Parameters.AddWithValue("@c", c);
                cmd.Parameters.AddWithValue("@m", "Legal notice: Please clear dues immediately.");
                con.Open(); cmd.ExecuteNonQuery(); con.Close();
                string result = "";
                // Try sending email if we can find customer's email via Connections
                SqlConnection con2 = DBHandler.GetConnection();
                SqlDataAdapter da = new SqlDataAdapter("SELECT TOP 1 email FROM Connections WHERE consumer_number=@c ORDER BY created_at DESC", con2);
                da.SelectCommand.Parameters.AddWithValue("@c", c);
                System.Data.DataTable dt = new System.Data.DataTable(); da.Fill(dt);
                if (dt.Rows.Count>0) {
                    string email = dt.Rows[0][0].ToString();
                    result = ElectricityBillWebApp.Classes.EmailService.SendMail(email, "Legal Notice - Electricity Dues", "<p>Dear Customer,<br/>Your dues exceed Rs. 2,00,000 and are pending for over a year. Please clear immediately.</p>");
                }
                lblMsg.Text = "Notice recorded. Email: " + (string.IsNullOrEmpty(result)?"(not sent / not configured)":result) + ".";
            }
            catch (Exception ex){ lblMsg.Text = "Error: " + ex.Message; }
        }
    }
}
