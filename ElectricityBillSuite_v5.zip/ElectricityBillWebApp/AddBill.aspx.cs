using System;
using System.Collections.Generic;
using ElectricityBillWebApp.Classes;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class AddBill : System.Web.UI.Page
    {
        ElectricityBoard eb = new ElectricityBoard();
        protected void btnGen_Click(object sender, EventArgs e)
        {
            try
            {
                string c = txtConsumer.Text;
                if (!eb.IsValidConsumerNumber(c))
                {
                    throw new FormatException("Invalid Consumer Number");
                }
                ElectricityBill b = new ElectricityBill();
                b.ConsumerNumber = c;
                b.ConsumerName = txtName.Text;
                int u = Convert.ToInt32(txtUnits.Text);
                var vv = new BillValidator();
                string msg = vv.ValidateUnitsConsumed(u);
                if (msg != "OK")
                {
                    lblMsg.Text = msg;
                    return;
                }
                b.UnitsConsumed = u;
                eb.CalculateBill(b);
                eb.AddBill(b);
                lblMsg.Text = b.ConsumerNumber + " " + b.ConsumerName + " " + b.UnitsConsumed + " Bill Amount : " + b.BillAmount;
            }
            catch (FormatException fe)
            {
                lblMsg.Text = fe.Message;
            }
            catch (Exception ex)
            {
                lblMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void btnFetch_Click(object sender, EventArgs e)
        {
            int n = 1;
            int.TryParse(txtN.Text, out n);
            List<ElectricityBill> list = eb.Generate_N_BillDetails(n);
            grid.DataSource = list;
            grid.DataBind();
        }
    }
}
