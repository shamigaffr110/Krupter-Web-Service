using System;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = EB.Data.DBHandler.GetConnection();
            string q = "SELECT admin_id FROM Admins WHERE username=@u AND password=@p";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@u", txtUser.Text);
            cmd.Parameters.AddWithValue("@p", txtPass.Text);
            con.Open();
            object x = cmd.ExecuteScalar();
            con.Close();
            if (x != null) { Session["admin"] = txtUser.Text; Response.Redirect("AddBill.aspx"); }
            else { lblMsg.Text = "Invalid admin"; }
        }
    }
}
