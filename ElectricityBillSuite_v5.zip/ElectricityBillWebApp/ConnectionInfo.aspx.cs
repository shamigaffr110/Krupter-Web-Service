using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;
namespace ElectricityBillWebApp
{
    public partial class ConnectionInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int uid = 0; if (Session["user_id"] != null) uid = Convert.ToInt32(Session["user_id"]);
                SqlConnection con = DBHandler.GetConnection();

                SqlDataAdapter da1 = new SqlDataAdapter("SELECT TOP 5 * FROM Connections WHERE user_id=@u ORDER BY created_at DESC", con);
                da1.SelectCommand.Parameters.AddWithValue("@u", uid);
                DataTable t1 = new DataTable(); da1.Fill(t1); gridConn.DataSource=t1; gridConn.DataBind();

                SqlDataAdapter da2 = new SqlDataAdapter("SELECT TOP 10 consumer_number,consumer_name,units_consumed,bill_amount,bill_date,status FROM ElectricityBill ORDER BY bill_date DESC", con);
                DataTable t2 = new DataTable(); da2.Fill(t2); gridBills.DataSource=t2; gridBills.DataBind();

                SqlDataAdapter da3 = new SqlDataAdapter("SELECT TOP 10 * FROM Payments WHERE user_id=@u ORDER BY payment_date DESC", con);
                da3.SelectCommand.Parameters.AddWithValue("@u", uid);
                DataTable t3 = new DataTable(); da3.Fill(t3); gridTxn.DataSource=t3; gridTxn.DataBind();
            }
        }
    }
}
