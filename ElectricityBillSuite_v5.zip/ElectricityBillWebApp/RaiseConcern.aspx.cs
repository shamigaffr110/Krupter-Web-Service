using System;
using System.Data.SqlClient;
using EB.Data;
namespace ElectricityBillWebApp
{
    public partial class RaiseConcern : System.Web.UI.Page
    {
        protected void btnSend_Click(object sender, EventArgs e)
        {
            try{
                int uid = 0;
                if (Session["user_id"] != null) uid = Convert.ToInt32(Session["user_id"]);
                SqlConnection con = DBHandler.GetConnection();
                SqlCommand cmd = new SqlCommand("INSERT INTO Concerns(user_id,consumer_number,message,status) VALUES(@u,@c,@m,'Open')", con);
                cmd.Parameters.AddWithValue("@u", uid);
                cmd.Parameters.AddWithValue("@c", txtConsumer.Text);
                cmd.Parameters.AddWithValue("@m", txtMessage.Text);
                con.Open(); cmd.ExecuteNonQuery(); con.Close();
                lblMsg.Text = "Concern submitted.";
            }catch(Exception ex){ lblMsg.Text = "Error: " + ex.Message; }
        }
    }
}
