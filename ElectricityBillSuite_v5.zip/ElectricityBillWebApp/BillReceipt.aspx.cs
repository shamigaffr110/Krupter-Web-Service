using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class BillReceipt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int pid = 0; int.TryParse(Request.QueryString["paymentId"], out pid);
                if (pid > 0)
                {
                    SqlConnection con = DBHandler.GetConnection();
                    SqlDataAdapter da = new SqlDataAdapter(@"SELECT p.payment_id,p.consumer_number,p.amount,p.payment_date,p.method,p.txn_ref,
                                e.consumer_name,e.units_consumed
                                FROM Payments p LEFT JOIN ElectricityBill e ON e.consumer_number=p.consumer_number
                                WHERE p.payment_id=@i", con);
                    da.SelectCommand.Parameters.AddWithValue("@i", pid);
                    DataTable dt = new DataTable(); da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        var r = dt.Rows[0];
                        lblInfo.Text = "Txn Ref: <b>" + r["txn_ref"] + "</b><br/>Consumer: <b>" + r["consumer_number"] + " - " + r["consumer_name"] +
                            "</b><br/>Amount: <b>Rs. " + r["amount"] + "</b><br/>Method: " + r["method"] +
                            "<br/>Date: " + Convert.ToDateTime(r["payment_date"]).ToString("yyyy-MM-dd HH:mm");
                        lnkPdf.NavigateUrl = "BillReceiptPdf.aspx?paymentId=" + pid;
                    }
                    else
                    {
                        lblInfo.Text = "Receipt not found";
                    }
                }
            }
        }
    }
}
