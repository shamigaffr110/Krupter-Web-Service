using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class RevenueReport : System.Web.UI.Page
    {
        protected void btnLoad_Click(object sender, EventArgs e)
        {
            DateTime f = DateTime.MinValue, t = DateTime.MaxValue;
            DateTime.TryParse(txtFrom.Text, out f);
            DateTime.TryParse(txtTo.Text, out t);
            SqlConnection con = DBHandler.GetConnection();
            string q = @"SELECT payment_id, consumer_number, amount, payment_date, method, status 
                        FROM Payments WHERE payment_date BETWEEN @f AND @t";
            if (!string.IsNullOrEmpty(txtName.Text))
            {
                q = q + " AND consumer_number IN (SELECT consumer_number FROM ElectricityBill WHERE consumer_name LIKE @name)";
            }
            SqlDataAdapter da = new SqlDataAdapter(q, con);
            da.SelectCommand.Parameters.AddWithValue("@f", f);
            da.SelectCommand.Parameters.AddWithValue("@t", t);
            if (!string.IsNullOrEmpty(txtName.Text))
            {
                da.SelectCommand.Parameters.AddWithValue("@name", "%" + txtName.Text + "%");
            }
            DataTable dt = new DataTable(); da.Fill(dt);
            grid.DataSource = dt; grid.DataBind();
            double sum = 0;
            foreach (System.Data.DataRow r in dt.Rows) { sum += Convert.ToDouble(r["amount"]); }
            lblTotal.Text = "Total Revenue: Rs. " + sum;
        }
    }
}
