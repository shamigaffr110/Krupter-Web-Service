using System;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class NewConnection : System.Web.UI.Page
    {
        protected void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                string idPath = "", photoPath = "";
                if (fuId.HasFile)
                {
                    idPath = "Uploads/IdProof/" + Guid.NewGuid().ToString().Substring(0,8) + "_" + fuId.FileName;
                    fuId.SaveAs(Server.MapPath("~/" + idPath));
                }
                if (fuPhoto.HasFile)
                {
                    photoPath = "Uploads/Photo/" + Guid.NewGuid().ToString().Substring(0,8) + "_" + fuPhoto.FileName;
                    fuPhoto.SaveAs(Server.MapPath("~/" + photoPath));
                }
                int userId = 0;
                if (Session["user_id"] != null) userId = Convert.ToInt32(Session["user_id"]);
                SqlConnection con = DBHandler.GetConnection();
                SqlCommand cmd = new SqlCommand(@"INSERT INTO Connections(user_id,name,phone,email,address,locality,type,load,connection_type,id_proof_path,photo_path,status) 
                VALUES(@u,@n,@p,@e,@a,@l,@t,@ld,@ct,@id,@ph,'Pending')", con);
                cmd.Parameters.AddWithValue("@u", userId);
                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@e", txtEmail.Text);
                cmd.Parameters.AddWithValue("@a", txtAddress.Text);
                cmd.Parameters.AddWithValue("@l", txtLocality.Text);
                cmd.Parameters.AddWithValue("@t", ddlType.SelectedValue);
                cmd.Parameters.AddWithValue("@ld", Convert.ToInt32(txtLoad.Text));
                cmd.Parameters.AddWithValue("@ct", ddlConnType.SelectedValue);
                cmd.Parameters.AddWithValue("@id", idPath);
                cmd.Parameters.AddWithValue("@ph", photoPath);
                con.Open(); cmd.ExecuteNonQuery(); con.Close();
                lblMsg.Text = "Application submitted. Please pay Rs. 8000 for registration on Payment page.";
            }
            catch (Exception ex){ lblMsg.Text = "Error: " + ex.Message; }
        }
    }
}
