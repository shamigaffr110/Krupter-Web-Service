using System;
using System.Data;
using System.Data.SqlClient;
using EB.Data;
using ElectricityBillWebApp.Classes;

namespace ElectricityBillWebApp
{
    public partial class BillReceiptPdf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int pid = 0; int.TryParse(Request.QueryString["paymentId"], out pid);
            if (pid <= 0)
            {
                Response.ContentType = "text/plain";
                Response.Write("Invalid paymentId");
                return;
            }
            SqlConnection con = DBHandler.GetConnection();
            SqlDataAdapter da = new SqlDataAdapter(@"SELECT p.payment_id,p.consumer_number,p.amount,p.payment_date,p.method,p.txn_ref,
                                e.consumer_name,e.units_consumed
                                FROM Payments p LEFT JOIN ElectricityBill e ON e.consumer_number=p.consumer_number
                                WHERE p.payment_id=@i", con);
            da.SelectCommand.Parameters.AddWithValue("@i", pid);
            DataTable dt = new DataTable(); da.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                Response.ContentType = "text/plain";
                Response.Write("Receipt not found");
                return;
            }
            var r = dt.Rows[0];
            string title = "EB Utility Suite - Payment Receipt";
            string[] lines = new string[] {
                "Payment ID: " + r["payment_id"],
                "Txn Ref: " + r["txn_ref"],
                "Consumer: " + r["consumer_number"] + " - " + r["consumer_name"],
                "Amount: Rs. " + r["amount"],
                "Method: " + r["method"],
                "Date: " + Convert.ToDateTime(r["payment_date"]).ToString("yyyy-MM-dd HH:mm")
            };
            byte[] pdf = TinyPdf.MakeSimpleReceipt(title, lines);
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment; filename=Receipt_" + r["payment_id"] + ".pdf");
            Response.BinaryWrite(pdf);
            Response.End();
        }
    }
}
