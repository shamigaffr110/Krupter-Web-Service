using System;
using System.Data.SqlClient;
using EB.Data;

namespace ElectricityBillWebApp
{
    public partial class UserLogin : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = DBHandler.GetConnection();
            string q = "SELECT user_id,name FROM Users WHERE email=@e AND password=@p";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@e", txtEmail.Text);
            cmd.Parameters.AddWithValue("@p", txtPass.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["user_id"] = Convert.ToInt32(dr["user_id"]);
                Session["user_name"] = dr["name"].ToString();
                Response.Redirect("ConnectionInfo.aspx");
            }
            else
            {
                lblMsg.Text = "Invalid login";
            }
            con.Close();
        }
    }
}
