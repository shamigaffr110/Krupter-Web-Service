using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace RailwayReservation
{
    public static class TicketGenerator
    {
        public static void SavePlainTicket(int bookingId, string customerName, int trainNumber, string trainName, string source, string destination, string classType, System.DateTime travelDate, System.DateTime bookingDate, int passengers, decimal amount)
        {
            // Generate plain ASCII ticket without any Unicode/graphics
            string dir = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "Tickets");
            if (!System.IO.Directory.Exists(dir)) System.IO.Directory.CreateDirectory(dir);
            string file = System.IO.Path.Combine(dir, $"Ticket_{bookingId}.pdf");

            using (System.IO.FileStream fs = new System.IO.FileStream(file, System.IO.FileMode.Create, System.IO.FileAccess.Write))
            {
                iTextSharp.text.Document doc = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4, 36, 36, 36, 36);
                iTextSharp.text.pdf.PdfWriter.GetInstance(doc, fs);
                doc.Open();

                var fontTitle = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.COURIER_BOLD, 14);
                var fontMono  = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.COURIER, 10);
                var fontMonoB = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.COURIER_BOLD, 10);

                string line = new string('-', 56);
                var p = new iTextSharp.text.Paragraph("RAILWAY RESERVATION SYSTEM\nBOOKING CONFIRMATION", fontTitle);
                p.Alignment = iTextSharp.text.Element.ALIGN_CENTER;
                doc.Add(p);
                doc.Add(new iTextSharp.text.Paragraph(line, fontMono));

                string d1 = $"Booking ID : {bookingId}           Date of Booking : {bookingDate:dd-MMM-yyyy}";
                string d2 = $"Train No   : {trainNumber}           Train Name      : {trainName}";
                string d3 = $"From       : {source}                 To              : {destination}";
                string d4 = $"Date of Journey : {travelDate:dd-MMM-yyyy}";
                string d5 = $"Class      : {classType}";

                foreach (var s in new[]{d1,d2,d3,d4,d5}) doc.Add(new iTextSharp.text.Paragraph(s, fontMono));

                doc.Add(new iTextSharp.text.Paragraph(line, fontMono));
                doc.Add(new iTextSharp.text.Paragraph("Passenger Name           Age   Gender   Berth/Seat No", fontMonoB));
                doc.Add(new iTextSharp.text.Paragraph(line, fontMono));
                // We don't store individual passenger rows; show count and N/A seat no
                doc.Add(new iTextSharp.text.Paragraph($"Passengers : {passengers}   (Seat assignment: N/A)", fontMono));

                doc.Add(new iTextSharp.text.Paragraph(line, fontMono));
                doc.Add(new iTextSharp.text.Paragraph($"Total Fare : INR {amount:0.00}", fontMonoB));
                doc.Add(new iTextSharp.text.Paragraph(line, fontMono));
                doc.Add(new iTextSharp.text.Paragraph("Have a safe journey!", fontMono));

                doc.Close();
            }
        }

        public static void SavePdfTicketFull(int bookingId, string customerName, string trainName, string classType, DateTime travelDate, int passengers, decimal amount)
        {
            string file = $"Ticket_{bookingId}_full.pdf";
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                Document doc = new Document();
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Railway Ticket"));
                doc.Add(new Paragraph($"BookingId: {bookingId}"));
                doc.Add(new Paragraph($"Customer: {customerName}"));
                doc.Add(new Paragraph($"Train: {trainName}"));
                doc.Add(new Paragraph($"Class: {classType}"));
                doc.Add(new Paragraph($"Passengers: {passengers}"));
                doc.Add(new Paragraph($"Travel Date: {travelDate:yyyy-MM-dd}"));
                doc.Add(new Paragraph($"Amount: {amount:C}"));
                doc.Close();
            }
        }

        public static void SavePdfTicket(int bookingId, string customerName, string trainName, string classType, DateTime travelDate)
        {
            string file = $"Ticket_{bookingId}.pdf";
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                Document doc = new Document();
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Railway Ticket"));
                doc.Add(new Paragraph($"BookingId: {bookingId}"));
                doc.Add(new Paragraph($"Customer: {customerName}"));
                doc.Add(new Paragraph($"Train: {trainName}"));
                doc.Add(new Paragraph($"Class: {classType}"));
                doc.Add(new Paragraph($"Travel Date: {travelDate:yyyy-MM-dd}"));
                doc.Close();
            }
        }
    }
}
