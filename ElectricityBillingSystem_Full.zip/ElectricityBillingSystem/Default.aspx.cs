using System;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadNotices();
    }
    private void LoadNotices()
    {
        try
        {
            var dt = DBHelper.ExecuteSelect("SELECT TOP 5 Title, Message, PostedDate FROM Notices ORDER BY PostedDate DESC");
            rptNotices.DataSource = dt;
            rptNotices.DataBind();
        }
        catch(Exception ex)
        {
            lblMsg.Text = "Error loading notices: " + ex.Message;
        }
    }
}
