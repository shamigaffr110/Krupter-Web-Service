
-- EBillDB SQL script: create tables and seed data
CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200),
    Username NVARCHAR(100) UNIQUE,
    Email NVARCHAR(200),
    PasswordHash NVARCHAR(200),
    Address NVARCHAR(500),
    CreatedOn DATETIME
);

CREATE TABLE Admins (
    AdminId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) UNIQUE,
    PasswordHash NVARCHAR(200),
    CreatedOn DATETIME
);

CREATE TABLE Connections (
    ConnectionId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    Address NVARCHAR(500),
    RequestDate DATETIME,
    IsApproved BIT DEFAULT 0
);

CREATE TABLE Bills (
    BillId INT IDENTITY(1,1) PRIMARY KEY,
    ConnectionId INT FOREIGN KEY REFERENCES Connections(ConnectionId),
    BillingMonth DATE,
    UnitsConsumed INT,
    Amount DECIMAL(10,2),
    DueDate DATE,
    IsPaid BIT DEFAULT 0
);

CREATE TABLE Payments (
    PaymentId INT IDENTITY(1,1) PRIMARY KEY,
    BillId INT FOREIGN KEY REFERENCES Bills(BillId),
    PaymentDate DATETIME,
    AmountPaid DECIMAL(10,2)
);

CREATE TABLE Notices (
    NoticeId INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200),
    Message NVARCHAR(MAX),
    PostedDate DATETIME
);

-- Seed admin and a user
INSERT INTO Admins (Username, PasswordHash, CreatedOn) VALUES ('admin', 'Admin@123', GETDATE());
INSERT INTO Users (FullName, Username, Email, PasswordHash, Address, CreatedOn) VALUES ('Test User','user1','user1@example.com','User@123','123 Main St', GETDATE());
INSERT INTO Connections (UserId, Address, RequestDate, IsApproved) VALUES (1, '123 Main St', GETDATE(), 1);

-- Sample bills
INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid) VALUES (1, DATEADD(month, -2, GETDATE()), 120, 600.00, DATEADD(day, 15, DATEADD(month, -2, GETDATE())), 1);
INSERT INTO Bills (ConnectionId, BillingMonth, UnitsConsumed, Amount, DueDate, IsPaid) VALUES (1, DATEADD(month, -1, GETDATE()), 150, 750.00, DATEADD(day, 15, DATEADD(month, -1, GETDATE())), 0);

INSERT INTO Notices (Title, Message, PostedDate) VALUES ('Welcome', 'Welcome to E-Billing System', GETDATE());
