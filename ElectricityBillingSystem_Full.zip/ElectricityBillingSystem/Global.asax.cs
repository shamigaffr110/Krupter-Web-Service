using System;
public class Global : System.Web.HttpApplication { }
