using System;
using System.Data;
using System.Text;
public partial class User_BillReceipt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!User.Identity.IsAuthenticated) Response.Redirect("~/Account/Login.aspx");
        if (!IsPostBack)
        {
            int billId = 0;
            if (int.TryParse(Request.QueryString["billId"], out billId) && billId>0)
            {
                var dt = DBHelper.ExecuteSelect(@"SELECT b.BillId, b.BillingMonth, b.UnitsConsumed, b.Amount, b.DueDate, u.FullName, u.Address, c.ConnectionId
                    FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE b.BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
                if (dt.Rows.Count>0)
                {
                    var r = dt.Rows[0];
                    var sb = new StringBuilder();
                    sb.AppendLine("<div><strong>Customer:</strong> " + r["FullName"] + "</div>");
                    sb.AppendLine("<div><strong>Address:</strong> " + r["Address"] + "</div>");
                    sb.AppendLine("<div><strong>Connection ID:</strong> " + r["ConnectionId"] + "</div>");
                    sb.AppendLine("<div><strong>Billing Month:</strong> " + Convert.ToDateTime(r["BillingMonth"]).ToString("MMMM yyyy") + "</div>");
                    sb.AppendLine("<div><strong>Units:</strong> " + r["UnitsConsumed"] + " kWh</div>");
                    sb.AppendLine("<div><strong>Amount:</strong> ₹" + r["Amount"] + "</div>");
                    sb.AppendLine("<div><strong>Due Date:</strong> " + Convert.ToDateTime(r["DueDate"]).ToShortDateString() + "</div>");
                    ltReceipt.Text = sb.ToString();
                }
            }
        }
    }
}
