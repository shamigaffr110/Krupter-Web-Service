using System;
using System.Data;
using System.Text;
public partial class User_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!User.Identity.IsAuthenticated) Response.Redirect("~/Account/Login.aspx");
        if (!IsPostBack) { LoadBills(); LoadChart(); }
    }
    private void LoadBills()
    {
        // get username from identity
        var username = User.Identity.Name;
        var dt = DBHelper.ExecuteSelect(@"SELECT b.BillId, b.BillingMonth, b.UnitsConsumed, b.Amount, b.IsPaid
            FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId
            WHERE u.Username=@u ORDER BY b.BillingMonth DESC", new System.Data.SqlClient.SqlParameter("@u", username));
        gvBills.DataSource = dt; gvBills.DataBind();
    }
    protected void gvBills_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Pay" || e.CommandName == "Download")
        {
            int rowIndex = Convert.ToInt32(((System.Web.UI.WebControls.GridViewRow)((System.Web.UI.WebControls.Button)e.CommandSource).NamingContainer).RowIndex);
            int billId = Convert.ToInt32(gvBills.DataKeys[rowIndex].Value);
            if (e.CommandName == "Pay")
            {
                var amt = DBHelper.ExecuteScalar("SELECT Amount FROM Bills WHERE BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
                DBHelper.ExecuteNonQuery("UPDATE Bills SET IsPaid=1 WHERE BillId=@id", new System.Data.SqlClient.SqlParameter("@id", billId));
                DBHelper.ExecuteNonQuery("INSERT INTO Payments(BillId,PaymentDate,AmountPaid) VALUES(@b,GETDATE(),@a)", new System.Data.SqlClient.SqlParameter("@b", billId), new System.Data.SqlClient.SqlParameter("@a", amt));
                lblMsg.Text = "Payment simulated and recorded.";
                LoadBills();
            }
            else
            {
                Response.Redirect("~/User/BillReceipt.aspx?billId=" + billId);
            }
        }
    }
    private void LoadChart()
    {
        var username = User.Identity.Name;
        var dt = DBHelper.ExecuteSelect(@"SELECT TOP 6 b.BillingMonth, b.UnitsConsumed FROM Bills b JOIN Connections c ON b.ConnectionId=c.ConnectionId JOIN Users u ON c.UserId=u.UserId WHERE u.Username=@u ORDER BY b.BillingMonth DESC", new System.Data.SqlClient.SqlParameter("@u", username));
        // build arrays
        var months = new System.Collections.Generic.List<string>();
        var units = new System.Collections.Generic.List<int>();
        foreach(System.Data.DataRow r in dt.Rows)
        {
            months.Add(Convert.ToDateTime(r["BillingMonth"]).ToString("MMM yyyy"));
            units.Add(Convert.ToInt32(r["UnitsConsumed"]));
        }
        months.Reverse(); units.Reverse();
        var labels = System.Web.Script.Serialization.JavaScriptSerializer().Serialize(months);
        var data = System.Web.Script.Serialization.JavaScriptSerializer().Serialize(units);
        var sb = new StringBuilder();
        sb.AppendLine("<script>");
        sb.AppendLine($"var ctx = document.getElementById('consumptionChart').getContext('2d');");
        sb.AppendLine("new Chart(ctx, { type: 'bar', data: { labels: " + labels + ", datasets: [{ label: 'Units', data: " + data + ", backgroundColor: '#0B74B0' }] }, options: { responsive:true } });");
        sb.AppendLine("</script>");
        ltChartData.Text = sb.ToString();
    }
}
