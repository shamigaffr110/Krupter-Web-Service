using System;
using System.Data;
using System.Data.SqlClient;
public partial class Admin_AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadPending();
    }
    private void LoadPending()
    {
        var dt = DBHelper.ExecuteSelect("SELECT c.ConnectionId, u.FullName, c.Address FROM Connections c JOIN Users u ON c.UserId=u.UserId WHERE c.IsApproved=0");
        gvPending.DataSource = dt;
        gvPending.DataBind();
    }
    protected void gvPending_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Approve")
        {
            int rowIndex = Convert.ToInt32(((System.Web.UI.WebControls.GridViewRow)((System.Web.UI.WebControls.Button)e.CommandSource).NamingContainer).RowIndex);
            int connId = Convert.ToInt32(gvPending.DataKeys[rowIndex].Value);
            DBHelper.ExecuteNonQuery("UPDATE Connections SET IsApproved=1 WHERE ConnectionId=@id", new SqlParameter("@id", connId));
            lblMsg.Text = "Connection approved.";
            LoadPending();
        }
    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        // Generate bills for approved connections for current month
        var month = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        DBHelper.ExecuteNonQuery(@"INSERT INTO Bills(ConnectionId,BillingMonth,UnitsConsumed,Amount,DueDate,IsPaid)
            SELECT c.ConnectionId, @m, FLOOR(RAND(CHECKSUM(NEWID()))*200+50), 0, DATEADD(day,15,@m), 0 FROM Connections c WHERE c.IsApproved=1",
            new SqlParameter("@m", month));
        // update amount with rate 5 per unit
        DBHelper.ExecuteNonQuery("UPDATE Bills SET Amount = UnitsConsumed * 5.0 WHERE BillingMonth=@m", new SqlParameter("@m", month));
        lblMsg.Text = "Bills generated for " + month.ToString("yyyy-MM");
    }
    protected void btnRefresh_Click(object sender, EventArgs e) { LoadPending(); }
}
