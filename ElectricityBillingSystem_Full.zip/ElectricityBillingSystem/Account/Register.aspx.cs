using System;
using System.Data.SqlClient;
public partial class Account_Register : System.Web.UI.Page
{
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        try
        {
            var sql = "INSERT INTO Users(FullName, Username, Email, PasswordHash, Address, CreatedOn) VALUES(@fn,@u,@e,@p,@a,GETDATE())";
            var rows = DBHelper.ExecuteNonQuery(sql,
                new SqlParameter("@fn", txtFullName.Text.Trim()),
                new SqlParameter("@u", txtUsername.Text.Trim()),
                new SqlParameter("@e", txtEmail.Text.Trim()),
                new SqlParameter("@p", txtPassword.Text.Trim()),
                new SqlParameter("@a", txtAddress.Text.Trim()));
            if (rows > 0)
            {
                // create connection request
                var uid = DBHelper.ExecuteScalar("SELECT UserId FROM Users WHERE Username=@u", new SqlParameter("@u", txtUsername.Text.Trim()));
                DBHelper.ExecuteNonQuery("INSERT INTO Connections(UserId,Address,RequestDate,IsApproved) VALUES(@uid,@addr,GETDATE(),0)",
                    new SqlParameter("@uid", uid), new SqlParameter("@addr", txtAddress.Text.Trim()));
                lblMsg.Text = "Registered. Connection request submitted.";
            }
        }
        catch(Exception ex) { lblMsg.Text = ex.Message; }
    }
}
