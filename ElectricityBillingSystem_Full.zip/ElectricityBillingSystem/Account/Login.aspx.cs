using System;
using System.Data.SqlClient;
using System.Web.Security;
public partial class Account_Login : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            var dt = DBHelper.ExecuteSelect("SELECT UserId, FullName FROM Users WHERE Username=@u AND PasswordHash=@p",
                new SqlParameter("@u", txtUsername.Text.Trim()),
                new SqlParameter("@p", txtPassword.Text.Trim()));
            if (dt.Rows.Count > 0)
            {
                FormsAuthentication.SetAuthCookie(txtUsername.Text.Trim(), false);
                Response.Redirect("~/User/Dashboard.aspx");
            }
            else
            {
                // check admin
                var ad = DBHelper.ExecuteSelect("SELECT AdminId FROM Admins WHERE Username=@u AND PasswordHash=@p",
                    new SqlParameter("@u", txtUsername.Text.Trim()),
                    new SqlParameter("@p", txtPassword.Text.Trim()));
                if (ad.Rows.Count > 0)
                {
                    FormsAuthentication.SetAuthCookie(txtUsername.Text.Trim(), false);
                    Response.Redirect("~/Admin/AdminDashboard.aspx");
                }
                else
                {
                    lblMsg.Text = "Invalid credentials.";
                }
            }
        }
        catch(Exception ex) { lblMsg.Text = ex.Message; }
    }
}
