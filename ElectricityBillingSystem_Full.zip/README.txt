Electricity Billing System - Full Project (production-ready scaffold)
Contents:
- ElectricityBillingSystem.sln
- ElectricityBillingSystem (project folder)
  - .csproj, Web.config, Site.master, Default.aspx, Account/, Admin/, User/, App_Code/, Styles/, Images/, App_Data/EBillDB.sql
Setup:
1. Open ElectricityBillingSystem.sln in Visual Studio 2017/2019/2022.
2. Attach or run the SQL script to create the database:
   - Open SQL Server / LocalDB and run the script at ElectricityBillingSystem\App_Data\EBillDB.sql
   - Or use Visual Studio Server Explorer: Add Connection -> select the database file or a SQL Server instance and run script.
3. Update connection string in Web.config if needed.
4. Build and run (F5). Default pages: Default.aspx, Account/Login.aspx, Account/Register.aspx.
Seed credentials in SQL script:
- Admin: username = admin, password = Admin@123
- User: username = user1, password = User@123
Notes:
- Passwords in seed are plaintext for convenience. Replace with hashed passwords for production.
- Pages include designer.cs files, code-behind, and styling per Adani-inspired theme.
- Charts use Chart.js via CDN.
