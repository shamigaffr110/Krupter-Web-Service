Railway Reservation Normalized Project (fixed TrainDataAccess)
Steps:
1. Run SQL/schema.sql on your SQL Server to create DB and sample data.
2. Open RailwayReservation.sln in Visual Studio (.NET Framework 4.7.2).
3. Install iTextSharp NuGet package (or put DLL in packages folder as referenced).
4. Update DatabaseConnection.SetConnectionString(...) in Program.cs with your SQL Server connection string.
5. Build and run.
Note: TrainDataAccess uses Convert.ToInt32(rd["TrainNumber"]) to avoid implicit conversion errors.
