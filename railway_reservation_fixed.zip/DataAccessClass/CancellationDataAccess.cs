using System.Data.SqlClient;

namespace RailwayReservation.DataAccessClass
{
    public class CancellationDataAccess
    {
        public void Cancel(int bookingId)
        {
            using (SqlConnection conn = DatabaseConnection.GetConnection())
            {
                conn.Open();
                var ins = new SqlCommand("INSERT INTO Cancellations (BookingId,CancelDate) VALUES(@b,GETDATE())", conn);
                ins.Parameters.AddWithValue("@b", bookingId);
                ins.ExecuteNonQuery();

                var upd = new SqlCommand("UPDATE Reservations SET CurrentStatus='Cancelled' WHERE BookingId=@b", conn);
                upd.Parameters.AddWithValue("@b", bookingId);
                upd.ExecuteNonQuery();
            }
        }
    }
}