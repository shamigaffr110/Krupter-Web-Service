using System.Data.SqlClient;
using RailwayReservation.Models;

namespace RailwayReservation.DataAccessClass
{
    public class CustomerDataAccess
    {
        public bool Login(string email, string pass)
        {
            using (SqlConnection conn = DatabaseConnection.GetConnection())
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT COUNT(*) FROM Customers WHERE CustEmail=@e AND CustPassword=@p", conn);
                cmd.Parameters.AddWithValue("@e", email);
                cmd.Parameters.AddWithValue("@p", pass);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        public int Register(Customer c)
        {
            using (SqlConnection conn = DatabaseConnection.GetConnection())
            {
                conn.Open();
                var cmd = new SqlCommand("INSERT INTO Customers (CustName,CustPhone,CustEmail,CustPassword) VALUES(@n,@ph,@e,@p); SELECT CAST(SCOPE_IDENTITY() AS INT);", conn);
                cmd.Parameters.AddWithValue("@n", c.CustName);
                cmd.Parameters.AddWithValue("@ph", c.CustPhone);
                cmd.Parameters.AddWithValue("@e", c.CustEmail);
                cmd.Parameters.AddWithValue("@p", c.CustPassword);
                var obj = cmd.ExecuteScalar();
                return obj != null ? (int)obj : 0;
            }
        }
    }
}