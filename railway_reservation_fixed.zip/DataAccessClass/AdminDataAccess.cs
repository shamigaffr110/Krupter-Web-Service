using System.Data.SqlClient;

namespace RailwayReservation.DataAccessClass
{
    public class AdminDataAccess
    {
        public bool Login(string user, string pass)
        {
            using (SqlConnection conn = DatabaseConnection.GetConnection())
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT COUNT(*) FROM Admins WHERE AdminUsername=@u AND AdminPassword=@p", conn);
                cmd.Parameters.AddWithValue("@u", user);
                cmd.Parameters.AddWithValue("@p", pass);
                int c = (int)cmd.ExecuteScalar();
                return c > 0;
            }
        }
    }
}