using System;
namespace RailwayReservation.Models
{
    public class Reservation
    {
        public int BookingId { get; set; }
        public int CustId { get; set; }
        public int TrainClassId { get; set; }
        public DateTime TravelDate { get; set; }
        public string CurrentStatus { get; set; }
        public DateTime BookingDate { get; set; }
    }
}