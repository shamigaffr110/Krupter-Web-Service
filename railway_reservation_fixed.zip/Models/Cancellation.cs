using System;
namespace RailwayReservation.Models
{
    public class Cancellation
    {
        public int CancelId { get; set; }
        public int BookingId { get; set; }
        public DateTime CancelDate { get; set; }
    }
}