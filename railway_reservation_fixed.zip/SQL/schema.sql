-- Normalized schema
CREATE TABLE Admins (
    AdminId INT IDENTITY(1,1) PRIMARY KEY,
    AdminUsername VARCHAR(50) NOT NULL,
    AdminPassword VARCHAR(50) NOT NULL
);

CREATE TABLE Customers (
    CustId INT IDENTITY(1,1) PRIMARY KEY,
    CustName VARCHAR(100) NOT NULL,
    CustPhone VARCHAR(15) NOT NULL,
    CustEmail VARCHAR(100) NOT NULL,
    CustPassword VARCHAR(50) NOT NULL
);

CREATE TABLE TrainMaster (
    TrainNumber INT PRIMARY KEY,
    TrainName VARCHAR(100) NOT NULL,
    Source VARCHAR(50) NOT NULL,
    Destination VARCHAR(50) NOT NULL
);

CREATE TABLE TrainClasses (
    TrainClassId INT IDENTITY(1,1) PRIMARY KEY,
    TrainNumber INT NOT NULL FOREIGN KEY REFERENCES TrainMaster(TrainNumber),
    ClassType VARCHAR(20) NOT NULL, -- 'Sleeper','AC3','AC2','AC1'
    AvailableSeats INT NOT NULL,
    MaxSeats INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL
);

CREATE TABLE Reservations (
    BookingId INT IDENTITY(1,1) PRIMARY KEY,
    CustId INT NOT NULL FOREIGN KEY REFERENCES Customers(CustId),
    TrainClassId INT NOT NULL FOREIGN KEY REFERENCES TrainClasses(TrainClassId),
    TravelDate DATE NOT NULL,
    CurrentStatus VARCHAR(20) NOT NULL DEFAULT 'Confirmed',
    BookingDate DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE Cancellations (
    CancelId INT IDENTITY(1,1) PRIMARY KEY,
    BookingId INT NOT NULL FOREIGN KEY REFERENCES Reservations(BookingId),
    CancelDate DATETIME NOT NULL DEFAULT GETDATE()
);

GO
-- Trigger: decrement available seats after booking
CREATE TRIGGER trg_DecrementSeats_AfterInsertReservation
ON Reservations
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @TrainClassId INT;
    SELECT @TrainClassId = TrainClassId FROM inserted;
    UPDATE TrainClasses SET AvailableSeats = AvailableSeats - 1 WHERE TrainClassId = @TrainClassId AND AvailableSeats > 0;
END;
GO
-- Trigger: increment available seats after cancellation (not exceeding MaxSeats)
CREATE TRIGGER trg_IncrementSeats_AfterInsertCancellation
ON Cancellations
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @BookingId INT, @TrainClassId INT;
    SELECT @BookingId = BookingId FROM inserted;
    SELECT @TrainClassId = TrainClassId FROM Reservations WHERE BookingId = @BookingId;
    UPDATE TrainClasses SET AvailableSeats = CASE WHEN AvailableSeats < MaxSeats THEN AvailableSeats + 1 ELSE AvailableSeats END WHERE TrainClassId = @TrainClassId;
END;
GO

-- Sample data
INSERT INTO Admins (AdminUsername, AdminPassword) VALUES ('admin','admin123');
INSERT INTO Customers (CustName, CustPhone, CustEmail, CustPassword) VALUES ('John Doe','9876543210','john@example.com','pass123');
INSERT INTO TrainMaster (TrainNumber,TrainName,Source,Destination) VALUES (101,'Express A','CityA','CityB');
INSERT INTO TrainClasses (TrainNumber,ClassType,AvailableSeats,MaxSeats,Price) VALUES (101,'Sleeper',50,50,200),(101,'AC3',40,40,500),(101,'AC2',30,30,800),(101,'AC1',20,20,1200);
