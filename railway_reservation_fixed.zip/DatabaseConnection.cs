using System.Data.SqlClient;

namespace RailwayReservation
{
    public static class DatabaseConnection
    {
        private static string _connectionString;
        public static void SetConnectionString(string cs) { _connectionString = cs; }
        public static SqlConnection GetConnection() { return new SqlConnection(_connectionString); }
    }
}