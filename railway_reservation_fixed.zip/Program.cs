using System;
using RailwayReservation.DataAccessClass;
using RailwayReservation.Models;

namespace RailwayReservation
{
    class Program
    {
        static void Main(string[] args)
        {
            DatabaseConnection.SetConnectionString("Server=YOUR_SERVER;Database=RailwayDB;Trusted_Connection=True;");
            while (true)
            {
                Console.WriteLine("\nRailway Reservation System");
                Console.WriteLine("1. Admin Login");
                Console.WriteLine("2. Customer Login");
                Console.WriteLine("3. Customer Register");
                Console.WriteLine("4. Exit");
                Console.Write("Choice: ");
                var ch = Console.ReadLine();
                if (ch == "1") AdminFlow();
                else if (ch == "2") CustomerFlow();
                else if (ch == "3") RegisterCustomer();
                else if (ch == "4") break;
            }
        }

        static void AdminFlow()
        {
            Console.Write("Admin username: "); var u = Console.ReadLine();
            Console.Write("Password: "); var p = Console.ReadLine();
            var ada = new AdminDataAccess();
            if (!ada.Login(u, p)) { Console.WriteLine("Invalid admin."); return; }
            Console.WriteLine("Admin logged in.");
            var tda = new TrainDataAccess();
            var rda = new ReportDataAccess();
            while (true)
            {
                Console.WriteLine("\nAdmin Menu: 1-add train 2-add class 3-report 4-back");
                Console.Write("Choice: "); var c = Console.ReadLine();
                if (c == "1")
                {
                    Console.Write("TrainNumber: "); int tn = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("TrainName: "); string tnname = Console.ReadLine();
                    Console.Write("Source: "); string src = Console.ReadLine();
                    Console.Write("Destination: "); string dest = Console.ReadLine();
                    using (var conn = DatabaseConnection.GetConnection())
                    {
                        conn.Open();
                        var cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO TrainMaster (TrainNumber,TrainName,Source,Destination) VALUES(@tn,@n,@s,@d)", conn);
                        cmd.Parameters.AddWithValue("@tn", tn);
                        cmd.Parameters.AddWithValue("@n", tnname);
                        cmd.Parameters.AddWithValue("@s", src);
                        cmd.Parameters.AddWithValue("@d", dest);
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Train added."); 
                    }
                }
                else if (c == "2")
                {
                    Console.Write("TrainNumber: "); int tn = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("ClassType (Sleeper/AC3/AC2/AC1): "); string cl = Console.ReadLine();
                    Console.Write("AvailableSeats: "); int av = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("MaxSeats: "); int mx = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("Price: "); decimal pr = decimal.Parse(Console.ReadLine() ?? "0");
                    using (var conn = DatabaseConnection.GetConnection())
                    {
                        conn.Open();
                        var cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO TrainClasses (TrainNumber,ClassType,AvailableSeats,MaxSeats,Price) VALUES(@tn,@cl,@av,@mx,@pr)", conn);
                        cmd.Parameters.AddWithValue("@tn", tn);
                        cmd.Parameters.AddWithValue("@cl", cl);
                        cmd.Parameters.AddWithValue("@av", av);
                        cmd.Parameters.AddWithValue("@mx", mx);
                        cmd.Parameters.AddWithValue("@pr", pr);
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Train class added."); 
                    }
                }
                else if (c == "3") rda.ShowReport();
                else break;
            }
        }

        static void RegisterCustomer()
        {
            var c = new Customer();
            Console.Write("Name: "); c.CustName = Console.ReadLine();
            Console.Write("Phone: "); c.CustPhone = Console.ReadLine();
            Console.Write("Email: "); c.CustEmail = Console.ReadLine();
            Console.Write("Password: "); c.CustPassword = Console.ReadLine();
            var cda = new CustomerDataAccess();
            int id = cda.Register(c);
            Console.WriteLine($"Registered CustId: {id}"); 
        }

        static void CustomerFlow()
        {
            Console.Write("Email: "); string e = Console.ReadLine();
            Console.Write("Password: "); string p = Console.ReadLine();
            var cda = new CustomerDataAccess();
            if (!cda.Login(e,p)) { Console.WriteLine("Invalid customer."); return; }
            Console.WriteLine("Customer logged in.");
            var tda = new TrainDataAccess();
            var rda = new ReservationDataAccess();
            var cnda = new CancellationDataAccess();
            while (true)
            {
                Console.WriteLine("\nCustomer Menu: 1-view trains 2-view classes 3-book 4-cancel 5-print 6-logout");
                Console.Write("Choice: "); var ch = Console.ReadLine();
                if (ch == "1")
                {
                    var trains = tda.GetAllTrains();
                    foreach (var t in trains) Console.WriteLine($"{t.TrainNumber} - {t.TrainName} ({t.Source}->{t.Destination})");
                }
                else if (ch == "2")
                {
                    Console.Write("Enter TrainNumber: "); int tn = int.Parse(Console.ReadLine() ?? "0");
                    var classes = tda.GetClassesForTrain(tn);
                    foreach (var cl in classes) Console.WriteLine($"{cl.TrainClassId} - {cl.ClassType} Seats:{cl.AvailableSeats}/{cl.MaxSeats} Price:{cl.Price}"); 
                }
                else if (ch == "3")
                {
                    Console.Write("CustId: "); int cid = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("TrainClassId: "); int tc = int.Parse(Console.ReadLine() ?? "0");
                    Console.Write("Travel Date (yyyy-mm-dd): "); var dt = DateTime.Parse(Console.ReadLine());
                    var bid = rda.Book(cid, tc, dt);
                    if (bid>0) Console.WriteLine($"Booked. BookingId: {bid}"); else Console.WriteLine("Booking failed (no seats).");
                }
                else if (ch == "4")
                {
                    Console.Write("BookingId to cancel: "); int bid = int.Parse(Console.ReadLine() ?? "0");
                    cnda.Cancel(bid);
                    Console.WriteLine("Cancellation processed."); 
                }
                else if (ch == "5")
                {
                    Console.Write("BookingId: "); int bid = int.Parse(Console.ReadLine() ?? "0");
                    using (var conn = DatabaseConnection.GetConnection())
                    {
                        conn.Open();
                        var cmd = new System.Data.SqlClient.SqlCommand("SELECT r.BookingId,c.CustName,t.TrainName,tc.ClassType,r.TravelDate FROM Reservations r JOIN Customers c ON r.CustId=c.CustId JOIN TrainClasses tc ON r.TrainClassId=tc.TrainClassId JOIN TrainMaster t ON tc.TrainNumber=t.TrainNumber WHERE r.BookingId=@b", conn);
                        cmd.Parameters.AddWithValue("@b", bid);
                        var rd = cmd.ExecuteReader();
                        if (rd.Read())
                        {
                            int bookingId = (int)rd[0];
                            string cust = rd[1].ToString();
                            string trainn = rd[2].ToString();
                            string cl = rd[3].ToString();
                            DateTime dt = (DateTime)rd[4];
                            TicketGenerator.SavePdfTicket(bookingId, cust, trainn, cl, dt);
                        }
                        else Console.WriteLine("Booking not found."); 
                    }
                }
                else break;
            }
        }
    }
}
