-- Normalized schema with Refunds table
CREATE TABLE Admins (
    AdminId INT IDENTITY(1,1) PRIMARY KEY,
    AdminUsername VARCHAR(50) NOT NULL,
    AdminPassword VARCHAR(50) NOT NULL
);

CREATE TABLE Customers (
    CustId INT IDENTITY(1,1) PRIMARY KEY,
    CustName VARCHAR(100) NOT NULL,
    CustPhone VARCHAR(15) NOT NULL,
    CustEmail VARCHAR(100) NOT NULL,
    CustPassword VARCHAR(50) NOT NULL
);

CREATE TABLE TrainMaster (
    TrainNumber INT PRIMARY KEY,
    TrainName VARCHAR(100) NOT NULL,
    Source VARCHAR(50) NOT NULL,
    Destination VARCHAR(50) NOT NULL
);

CREATE TABLE TrainClasses (
    TrainNumber INT NOT NULL,
    ClassType VARCHAR(20) NOT NULL, -- 'Sleeper', '2nd AC', '3rd AC'
    AvailableSeats INT NOT NULL,
    MaxSeats INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    CONSTRAINT PK_TrainClasses PRIMARY KEY (TrainNumber, ClassType),
    CONSTRAINT FK_TrainClasses_TrainMaster FOREIGN KEY (TrainNumber) REFERENCES TrainMaster(TrainNumber)
);
GO

-- Trigger: increment available seats after cancellation (not exceeding MaxSeats)
CREATE TRIGGER trg_IncrementSeats_AfterInsertCancellation
ON Cancellations
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @BookingId INT, @TrainClassId INT;
    SELECT @BookingId = BookingId FROM inserted;
    SELECT @TrainClassId = TrainClassId FROM Reservations WHERE BookingId = @BookingId;
    UPDATE TrainClasses SET AvailableSeats = CASE WHEN AvailableSeats < MaxSeats THEN AvailableSeats + 1 ELSE AvailableSeats END WHERE TrainClassId = @TrainClassId;
END;
GO

-- Sample data
INSERT INTO Admins (AdminUsername, AdminPassword) VALUES ('admin','admin123');
INSERT INTO Customers (CustName, CustPhone, CustEmail, CustPassword) VALUES ('John Doe','9876543210','john@example.com','pass123');
INSERT INTO TrainMaster (TrainNumber,TrainName,Source,Destination) VALUES (101,'Express A','CityA','CityB');
INSERT INTO TrainClasses (TrainNumber,ClassType,AvailableSeats,MaxSeats,Price) VALUES (101,'Sleeper',100,100,300),(101,'3rd AC',40,40,500),(101,'2nd AC',30,30,800);
