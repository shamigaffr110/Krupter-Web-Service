using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace RailwayReservation
{
    public static class TicketGenerator
    {
        public static void SavePdfTicketFull(int bookingId, string customerName, string trainName, string classType, DateTime travelDate, int passengers, decimal amount)
        {
            string file = $"Ticket_{bookingId}_full.pdf";
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                Document doc = new Document();
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Railway Ticket"));
                doc.Add(new Paragraph($"BookingId: {bookingId}"));
                doc.Add(new Paragraph($"Customer: {customerName}"));
                doc.Add(new Paragraph($"Train: {trainName}"));
                doc.Add(new Paragraph($"Class: {classType}"));
                doc.Add(new Paragraph($"Passengers: {passengers}"));
                doc.Add(new Paragraph($"Travel Date: {travelDate:yyyy-MM-dd}"));
                doc.Add(new Paragraph($"Amount: {amount:C}"));
                doc.Close();
            }
        }

        public static void SavePdfTicket(int bookingId, string customerName, string trainName, string classType, DateTime travelDate)
        {
            string file = $"Ticket_{bookingId}.pdf";
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                Document doc = new Document();
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Railway Ticket"));
                doc.Add(new Paragraph($"BookingId: {bookingId}"));
                doc.Add(new Paragraph($"Customer: {customerName}"));
                doc.Add(new Paragraph($"Train: {trainName}"));
                doc.Add(new Paragraph($"Class: {classType}"));
                doc.Add(new Paragraph($"Travel Date: {travelDate:yyyy-MM-dd}"));
                doc.Close();
            }
        }
    }
}
