using System.Data.SqlClient;

namespace RailwayReservation
{
    public static class DatabaseConnection
    {
        private static SqlConnection con;
        private static string connectionString = "Server=YOUR_SERVER;Database=RailwayDB;Trusted_Connection=True;";
        public static SqlConnection getConnection()
        {
            con = new SqlConnection(connectionString);
            try { con.Open(); } catch (System.Exception ex) { throw new RailwayReservation.Exceptions.DataAccessException("Failed to open database connection.", ex); }
            return con;
        }
    }
}
