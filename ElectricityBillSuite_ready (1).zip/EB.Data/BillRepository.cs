using System;
using System.Data;
using System.Data.SqlClient;

namespace EB.Data
{
    public class BillRepository
    {
        public DataTable GetBillsByUser(int userId)
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand(@"SELECT b.*, c.MeterNumber FROM Bills b
JOIN Connections c ON b.ConnectionID=c.ConnectionID
WHERE c.CustomerID=@uid ORDER BY b.BillingMonth DESC", conn))
            {
                cmd.Parameters.AddWithValue("@uid", userId);
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public DataRow GetBill(int billId)
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("SELECT * FROM Bills WHERE BillID=@id", conn))
            {
                cmd.Parameters.AddWithValue("@id", billId);
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count==0) return null;
                    return dt.Rows[0];
                }
            }
        }

        public void MarkPaid(int billId, decimal amount)
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("INSERT INTO Payments (BillID, PaymentDate, Amount) VALUES (@b, GETDATE(), @amt)", conn))
            {
                cmd.Parameters.AddWithValue("@b", billId);
                cmd.Parameters.AddWithValue("@amt", amount);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("UPDATE Bills SET IsPaid=1 WHERE BillID=@b", conn))
            {
                cmd.Parameters.AddWithValue("@b", billId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public int GenerateBill(int connectionId, decimal units, decimal rate)
        {
            decimal amount = units * rate + 50;
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("INSERT INTO Bills (ConnectionID, BillingMonth, UnitsConsumed, AmountDue, DueDate, IsPaid, CreatedAt) OUTPUT INSERTED.BillID VALUES (@c, @m, @u, @a, @d, 0, GETDATE())", conn))
            {
                cmd.Parameters.AddWithValue("@c", connectionId);
                cmd.Parameters.AddWithValue("@m", DateTime.Today);
                cmd.Parameters.AddWithValue("@u", units);
                cmd.Parameters.AddWithValue("@a", amount);
                cmd.Parameters.AddWithValue("@d", DateTime.Today.AddDays(15));
                conn.Open();
                return (int)cmd.ExecuteScalar();
            }
        }
    }
}
