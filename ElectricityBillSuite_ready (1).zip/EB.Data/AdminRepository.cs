using System;
using System.Data;
using System.Data.SqlClient;

namespace EB.Data
{
    public class AdminRepository
    {
        public DataTable GetConnections()
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand(@"SELECT c.ConnectionID, u.FullName AS CustomerName, c.ConnectionType, c.Status FROM Connections c JOIN Users u ON c.CustomerID=u.UserID", conn))
            {
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public void UpdateConnectionStatus(int connId, string status)
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("UPDATE Connections SET Status=@s WHERE ConnectionID=@id", conn))
            {
                cmd.Parameters.AddWithValue("@s", status);
                cmd.Parameters.AddWithValue("@id", connId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
