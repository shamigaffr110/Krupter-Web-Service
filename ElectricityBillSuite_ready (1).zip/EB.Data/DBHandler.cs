using System.Configuration;
using System.Data.SqlClient;

namespace EB.Data
{
    public class DBHandler
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["EBConn"].ConnectionString);
            return con;
        }
    }
}
