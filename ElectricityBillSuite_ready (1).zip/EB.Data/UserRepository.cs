using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace EB.Data
{
    public class UserRepository
    {
        // Register: stores plain or hashed using PBKDF2
        public int Register(string fullName, string email, string password)
        {
            // hash password
            string hash = GenerateHash(password);
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("INSERT INTO Users (FullName, Email, PasswordHash, CreatedAt) OUTPUT INSERTED.UserID VALUES (@n,@e,@p,GETDATE())", conn))
            {
                cmd.Parameters.AddWithValue("@n", fullName);
                cmd.Parameters.AddWithValue("@e", email);
                cmd.Parameters.AddWithValue("@p", hash);
                conn.Open();
                return (int)cmd.ExecuteScalar();
            }
        }

        public DataRow GetUserByEmail(string email)
        {
            using (var conn = DBHandler.GetConnection())
            using (var cmd = new SqlCommand("SELECT TOP 1 * FROM Users WHERE Email=@e", conn))
            {
                cmd.Parameters.AddWithValue("@e", email);
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count==0) return null;
                    return dt.Rows[0];
                }
            }
        }

        public bool ValidateLogin(string email, string password, out int userId, out string fullName)
        {
            userId = 0; fullName = null;
            var row = GetUserByEmail(email);
            if (row==null) return false;
            string stored = row["PasswordHash"].ToString();
            // if stored looks like PBKDF2 format (iterations:salt:hash) then verify, else compare plain and upgrade
            if (stored.Contains(":")) // assume hashed
            {
                if (VerifyHash(password, stored))
                {
                    userId = Convert.ToInt32(row["UserID"]);
                    fullName = row["FullName"].ToString();
                    return true;
                }
                return false;
            }
            else
            {
                if (stored==password)
                {
                    // upgrade: replace with hash
                    var h = GenerateHash(password);
                    using (var conn = DBHandler.GetConnection())
                    using (var cmd = new SqlCommand("UPDATE Users SET PasswordHash=@p WHERE UserID=@id", conn))
                    {
                        cmd.Parameters.AddWithValue("@p", h);
                        cmd.Parameters.AddWithValue("@id", row["UserID"]);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                    userId = Convert.ToInt32(row["UserID"]);
                    fullName = row["FullName"].ToString();
                    return true;
                }
                return false;
            }
        }

        // PBKDF2 helpers
        private string GenerateHash(string password)
        {
            int iterations = 10000;
            byte[] salt = new byte[16];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(salt);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations);
            byte[] hash = pbkdf2.GetBytes(32);
            return string.Format("{0}:{1}:{2}", iterations, Convert.ToBase64String(salt), Convert.ToBase64String(hash));
        }

        private bool VerifyHash(string password, string stored)
        {
            try{
            var parts = stored.Split(':');
            int iterations = int.Parse(parts[0]);
            byte[] salt = Convert.FromBase64String(parts[1]);
            byte[] hash = Convert.FromBase64String(parts[2]);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations);
            byte[] test = pbkdf2.GetBytes(hash.Length);
            for(int i=0;i<hash.Length;i++) if (hash[i]!=test[i]) return false;
            return true;
            }catch{return false;}
        }
    }
}
