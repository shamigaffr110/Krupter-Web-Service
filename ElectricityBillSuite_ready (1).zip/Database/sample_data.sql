INSERT INTO AdminUsers (Username, Password) VALUES ('admin','admin123');

INSERT INTO Users (FullName, Email, PasswordHash) VALUES
('Test User','user1@example.com','pass123'),
('Second User','user2@example.com','pass456');

INSERT INTO Connections (CustomerID, MeterNumber, ConnectionType, Status) VALUES
(1,'MTR-1001','Residential','Active'),
(2,'MTR-1002','Residential','Pending');

-- sample bill
INSERT INTO Bills (ConnectionID, BillingMonth, UnitsConsumed, AmountDue, DueDate, IsPaid) VALUES
(1, '2025-08-01', 200, 1200.00, '2025-09-10', 0);
