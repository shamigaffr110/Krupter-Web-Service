using EB.Data;
using System;

public partial class Account_Register : System.Web.UI.Page
{
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        var repo = new UserRepository();
        int id = repo.Register(txtName.Text.Trim(), txtEmail.Text.Trim(), txtPass.Text.Trim());
        lblMsg.Text = "Registered successfully. Please login.";
    }
}
