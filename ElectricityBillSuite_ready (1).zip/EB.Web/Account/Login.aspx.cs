using EB.Data;
using System;
using System.Web;
using System.Web.Security;

public partial class Account_Login : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();
        string pass = txtPass.Text.Trim();
        var repo = new UserRepository();
        int userId; string fullName;
        if (repo.ValidateLogin(email, pass, out userId, out fullName))
        {
            FormsAuthentication.SetAuthCookie(email, false);
            Session["UserID"] = userId;
            Session["UserName"] = fullName;
            Response.Redirect("~/User/Dashboard.aspx");
        }
        else
        {
            lblMsg.Text = "Invalid credentials";
        }
    }
}
