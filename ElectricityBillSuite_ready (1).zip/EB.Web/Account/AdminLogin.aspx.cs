using EB.Data;
using System;
using System.Web;
using System.Web.Security;

public partial class Account_AdminLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        var dt = new AdminRepository().GetConnections(); // misuse to get repo; will check admin separately
        // simple admin auth: check AdminUsers table
        using (var conn = DBHandler.GetConnection())
        using (var cmd = new System.Data.SqlClient.SqlCommand("SELECT AdminID FROM AdminUsers WHERE Username=@u AND Password=@p", conn))
        {
            cmd.Parameters.AddWithValue("@u", txtUser.Text.Trim());
            cmd.Parameters.AddWithValue("@p", txtPass.Text.Trim());
            conn.Open();
            var res = cmd.ExecuteScalar();
            if (res != null)
            {
                FormsAuthentication.SetAuthCookie(txtUser.Text.Trim(), false);
                Session["IsAdmin"] = true;
                Response.Redirect("~/Admin/Dashboard.aspx");
            }
            else lblMsg.Text = "Invalid admin credentials";
        }
    }
}
