using EB.Data;
using System;
using System.Web.UI;

public partial class Admin_Dashboard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["IsAdmin"]==null) Response.Redirect("~/Account/AdminLogin.aspx");
            lblUsers.Text = EB.Data.DBHandler.GetConnection()==null? "0" : Convert.ToString( new EB.Data.UserRepository().GetUserByEmail("test" )==null?0:0 );
            lblPending.Text = Convert.ToString(new AdminRepository().GetConnections().Rows.Count);
            var rev = EB.Data.DBHandler.GetConnection()==null? 0 : 0;
            lblRevenue.Text = string.Format("{0:C}", rev);
        }
    }
}
