using EB.Data;
using System;
using System.Web.UI;

public partial class Admin_GenerateBills : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["IsAdmin"]==null) Response.Redirect("~/Account/AdminLogin.aspx");
        }
    }

    protected void btnGen_Click(object sender, EventArgs e)
    {
        var dt = new AdminRepository().GetConnections();
        int cnt=0;
        foreach (System.Data.DataRow r in dt.Rows)
        {
            if (r["Status"].ToString()=="Active")
            {
                int connId = Convert.ToInt32(r["ConnectionID"]);
                int billId = new BillRepository().GenerateBill(connId, 150, 5.5m);
                cnt++;
            }
        }
        lblMsg.Text = cnt + " bills generated.";
    }
}
