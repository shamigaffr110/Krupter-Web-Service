using EB.Data;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ManageConnections : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["IsAdmin"]==null) Response.Redirect("~/Account/AdminLogin.aspx");
            Bind();
        }
    }

    private void Bind()
    {
        gvConns.DataSource = new AdminRepository().GetConnections();
        gvConns.DataBind();
    }

    protected void gvConns_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName=="Approve") new AdminRepository().UpdateConnectionStatus(id, "Active");
        else new AdminRepository().UpdateConnectionStatus(id, "Rejected");
        Bind();
    }
}
