using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace EB.Web.App_Code
{
    public static class PdfHelper
    {
        public static string CreateBillPdf(string folder, int billId, string customer, decimal amount)
        {
            Directory.CreateDirectory(folder);
            string file = Path.Combine(folder, $"Bill_{billId}.pdf");
            using (var fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                var doc = new Document(PageSize.A4);
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Electricity Bill"));
                doc.Add(new Paragraph($"Bill ID: {billId}"));
                doc.Add(new Paragraph($"Customer: {customer}"));
                doc.Add(new Paragraph($"Amount: {amount:C}" ));
                doc.Close();
            }
            return file;
        }
    }
}
