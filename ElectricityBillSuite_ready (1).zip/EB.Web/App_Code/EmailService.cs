using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace EB.Web.App_Code
{
    public static class EmailService
    {
        public static void Send(string to, string subject, string body, string attachPath = null)
        {
            var smtp = ConfigurationManager.GetSection("system.net/mailSettings/smtp") as System.Net.Configuration.SmtpSection;
            var msg = new MailMessage();
            msg.From = new MailAddress(smtp.Network.UserName);
            msg.To.Add(to);
            msg.Subject = subject;
            msg.Body = body;
            msg.IsBodyHtml = true;
            if (!string.IsNullOrEmpty(attachPath)) msg.Attachments.Add(new Attachment(attachPath));
            var client = new SmtpClient(smtp.Network.Host, smtp.Network.Port)
            {
                Credentials = new NetworkCredential(smtp.Network.UserName, smtp.Network.Password),
                EnableSsl = smtp.Network.EnableSsl
            };
            client.Send(msg);
        }
    }
}
