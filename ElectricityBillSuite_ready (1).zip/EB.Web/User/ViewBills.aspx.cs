using EB.Data;
using System;
using System.Web.UI;

public partial class User_ViewBills : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"]==null) Response.Redirect("~/Account/Login.aspx");
            Bind();
        }
    }
    private void Bind()
    {
        int uid = Convert.ToInt32(Session["UserID"]);
        gvAllBills.DataSource = new BillRepository().GetBillsByUser(uid);
        gvAllBills.DataBind();
    }
}
