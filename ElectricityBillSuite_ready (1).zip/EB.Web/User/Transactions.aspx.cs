using EB.Data;
using System;
using System.Web.UI;

public partial class User_Transactions : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"]==null) Response.Redirect("~/Account/Login.aspx");
            Bind();
        }
    }

    private void Bind()
    {
        int uid = Convert.ToInt32(Session["UserID"]);
        string sql = @"SELECT p.PaymentID, p.BillID, p.PaymentDate, p.Amount FROM Payments p
JOIN Bills b ON p.BillID=b.BillID
JOIN Connections c ON b.ConnectionID=c.ConnectionID
WHERE c.CustomerID=@uid ORDER BY p.PaymentDate DESC";
        gvTrans.DataSource = EB.Data.DBHandler.GetConnection()==null? null : new EB.Data.BillRepository().GetBillsByUser(uid); // placeholder, simpler output
        gvTrans.DataBind();
    }
}
