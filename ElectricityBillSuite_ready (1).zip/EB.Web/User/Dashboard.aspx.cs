using EB.Data;
using System;
using System.Web.UI;

public partial class User_Dashboard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"]==null) Response.Redirect("~/Account/Login.aspx");
            lblName.Text = Session["UserName"]?.ToString();
            BindBills();
            BindNotices();
        }
    }

    private void BindBills()
    {
        int uid = Convert.ToInt32(Session["UserID"]);
        var dt = new BillRepository().GetBillsByUser(uid);
        gvBills.DataSource = dt;
        gvBills.DataBind();
    }

    private void BindNotices()
    {
        var dt = new System.Data.DataTable();
        using (var conn = DBHandler.GetConnection())
        using (var cmd = new System.Data.SqlClient.SqlCommand("SELECT TOP 5 Title, Body FROM Notices ORDER BY CreatedAt DESC", conn))
        using (var da = new System.Data.SqlClient.SqlDataAdapter(cmd))
        {
            da.Fill(dt);
        }
        rptNotices.DataSource = dt;
        rptNotices.DataBind();
    }
}
