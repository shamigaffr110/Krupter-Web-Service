using EB.Data;
using System;
using System.Web;
using System.Web.UI;

public partial class User_PayBill : Page
{
    protected int BillId => Convert.ToInt32(Request.QueryString["billId"] ?? "0");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"]==null) Response.Redirect("~/Account/Login.aspx");
            var bill = new BillRepository().GetBill(BillId);
            if (bill==null) { lblInfo.Text = "Bill not found"; btnPay.Visible=false; return;}
            lblInfo.Text = $"Bill #{BillId} - Amount: {Convert.ToDecimal(bill["AmountDue"]):C}";
        }
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        var bill = new BillRepository().GetBill(BillId);
        decimal amt = Convert.ToDecimal(bill["AmountDue"]);
        new BillRepository().MarkPaid(BillId, amt);
        // generate pdf
        string folder = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["NoticesFolder"] ?? "~/Assets/Notices/");
        var pdf = EB.Web.App_Code.PdfHelper.CreateBillPdf(folder, BillId, Session["UserName"].ToString(), amt);
        // send email
        try { EB.Web.App_Code.EmailService.Send(HttpContext.Current.User.Identity.Name, "Payment Receipt", "Thank you", pdf); } catch { }
        Response.Redirect("~/User/Transactions.aspx");
    }
}
