INSERT INTO AdminUsers (Username, Password) VALUES ('admin', 'admin');

INSERT INTO Users (FullName, Email, PasswordHash) VALUES
('Test User', 'user1@example.com', 'AMJt/4EGAc3gci7Bf4SET6o/wjm46mNFoOu79q9qPkwHkMqHBnuXR1VcYYkzw8v0/w=='),
('Another User', 'user2@example.com', 'ADKH4Um9bfWgbAnDj5owzKG7qArzKdzmjo+sHJnvccVGbm0nXvjoCFQJgBF0jOFe8g==');

INSERT INTO Connections (CustomerID, MeterNumber, ConnectionType, Status) VALUES
(1, 'MTR-1001', 'Residential', 'Active'),
(2, 'MTR-1002', 'Commercial', 'Pending');

INSERT INTO Bills (ConnectionID, BillingMonth, UnitsConsumed, AmountDue, DueDate, IsPaid) VALUES
(1, '2025-08-01', 200, 1200.00, '2025-09-10', 0);
