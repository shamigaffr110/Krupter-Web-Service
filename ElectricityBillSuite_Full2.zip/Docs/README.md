ElectricityBillSuite - Quickstart
--------------------------------

1. Open ElectricityBillSuite.sln in Visual Studio 2019+.
2. Update Web.config connection string (DBConn) to your SQL Server, and SMTP settings.
3. Run Database/schema.sql and Database/sample_data.sql to create DB and seed sample users.
   - User: user1@example.com / pass123
   - Admin: admin / admin
4. Build solution. If NuGet packages missing (iTextSharp), restore via Package Manager.
5. Ensure folder Assets/Notices is writable by the web app.
6. For production: replace SMTP, secure secrets, and implement additional validation.
