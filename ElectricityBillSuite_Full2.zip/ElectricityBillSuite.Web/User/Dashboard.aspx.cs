using System;
using EBS.Helpers;

public partial class User_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] == null) Response.Redirect("~/Account/Login.aspx");
            lblName.Text = Session["UserName"]?.ToString() ?? "User";
            LoadOutstanding();
            LoadNotices();
        }
    }

    private void LoadOutstanding()
    {
        int uid = Convert.ToInt32(Session["UserID" ]);
        string sql = @"SELECT b.BillID, b.BillingMonth, b.AmountDue FROM Bills b
                       JOIN Connections c ON b.ConnectionID=c.ConnectionID
                       WHERE c.CustomerID=@uid AND b.IsPaid=0";
        var dt = DbHelper.GetDataTable(sql, new System.Data.SqlClient.SqlParameter("@uid", uid));
        gvOutstanding.DataSource = dt;
        gvOutstanding.DataBind();
    }

    private void LoadNotices()
    {
        var dt = DbHelper.GetDataTable("SELECT TOP 5 Title, Body, CreatedAt FROM Notices ORDER BY CreatedAt DESC");
        rptNotices.DataSource = dt;
        rptNotices.DataBind();
    }
}
