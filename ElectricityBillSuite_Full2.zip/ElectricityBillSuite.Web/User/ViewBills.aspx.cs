using System;
using EBS.Helpers;

public partial class User_ViewBills : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] == null) Response.Redirect("~/Account/Login.aspx");
            BindBills();
        }
    }

    private void BindBills()
    {
        int uid = Convert.ToInt32(Session["UserID"]);
        string sql = @"SELECT b.* FROM Bills b
                       JOIN Connections c ON b.ConnectionID=c.ConnectionID
                       WHERE c.CustomerID=@uid ORDER BY b.BillingMonth DESC";
        var dt = DbHelper.GetDataTable(sql, new System.Data.SqlClient.SqlParameter("@uid", uid));
        gvBills.DataSource = dt;
        gvBills.DataBind();
    }
}
