using System;
using EBS.Helpers;

public partial class User_PayBill : System.Web.UI.Page
{
    protected int BillId => Convert.ToInt32(Request.QueryString["billId"] ?? "0");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] == null) Response.Redirect("~/Account/Login.aspx");
            LoadBill();
        }
    }

    private void LoadBill()
    {
        var dt = DbHelper.GetDataTable("SELECT b.AmountDue, b.BillingMonth FROM Bills b WHERE b.BillID=@id", new System.Data.SqlClient.SqlParameter("@id", BillId));
        if (dt.Rows.Count == 0) { lblInfo.Text = "Bill not found."; btnPay.Visible = false; return; }
        lblAmount.Text = "Amount: " + Convert.ToDecimal(dt.Rows[0]["AmountDue"]).ToString("C");
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        var dt = DbHelper.GetDataTable("SELECT AmountDue, ConnectionID FROM Bills WHERE BillID=@id", new System.Data.SqlClient.SqlParameter("@id", BillId));
        decimal amt = Convert.ToDecimal(dt.Rows[0]["AmountDue"]);
        DbHelper.ExecuteNonQuery("INSERT INTO Payments (BillID, PaymentDate, Amount) VALUES (@b, GETDATE(), @amt)", new System.Data.SqlClient.SqlParameter("@b", BillId), new System.Data.SqlClient.SqlParameter("@amt", amt));
        DbHelper.ExecuteNonQuery("UPDATE Bills SET IsPaid=1 WHERE BillID=@b", new System.Data.SqlClient.SqlParameter("@b", BillId));
        string noticesFolder = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["NoticesFolder"]);
        var pdf = PdfHelper.CreateSimpleBillPdf(noticesFolder, BillId, Session["UserName"].ToString(), amt, DateTime.Today.AddDays(15));
        try { EmailService.Send(Session["UserName"].ToString(), "Payment receipt", "Thank you", pdf); } catch { }
        Response.Redirect("~/User/Transactions.aspx");
    }
}
