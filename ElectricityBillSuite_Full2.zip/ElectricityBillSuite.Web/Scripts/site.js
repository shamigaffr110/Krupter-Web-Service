// site scripts
$(function(){ console.log('site ready'); });