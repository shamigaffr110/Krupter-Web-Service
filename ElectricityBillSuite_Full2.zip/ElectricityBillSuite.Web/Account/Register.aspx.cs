using System;
using System.Data.SqlClient;
using EBS.Helpers;

public partial class Account_Register : System.Web.UI.Page
{
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string name = txtName.Text.Trim();
        string email = txtEmail.Text.Trim();
        string pass = txtPassword.Text.Trim();
        var hashed = DbHelper.HashPassword(pass);
        var sql = "INSERT INTO Users (FullName, Email, PasswordHash, CreatedAt) VALUES (@n,@e,@p,GETDATE())";
        DbHelper.ExecuteNonQuery(sql, new SqlParameter("@n", name), new SqlParameter("@e", email), new SqlParameter("@p", hashed));
        lblMsg.Text = "Registered successfully. Please login.";
    }
}
