using System;
using System.Data.SqlClient;
using EBS.Helpers;
using System.Web.Security;

public partial class Account_AdminLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string u = txtUser.Text.Trim();
        string p = txtPass.Text.Trim();
        var dt = DbHelper.GetDataTable("SELECT AdminID, Password FROM AdminUsers WHERE Username=@u", new SqlParameter("@u", u));
        if (dt.Rows.Count == 0) { lblMsg.Text = "Invalid"; return; }
        var stored = dt.Rows[0]["Password"].ToString();
        if (stored != p) { lblMsg.Text = "Invalid"; return; }
        FormsAuthentication.SetAuthCookie(u, false);
        Session["IsAdmin"] = true;
        Response.Redirect("~/Admin/Dashboard.aspx");
    }
}
