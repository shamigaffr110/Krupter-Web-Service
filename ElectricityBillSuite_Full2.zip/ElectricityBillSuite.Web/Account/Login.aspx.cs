using System;
using System.Web.Security;
using System.Data.SqlClient;
using EBS.Helpers;

public partial class Account_Login : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();
        string pass = txtPassword.Text.Trim();
        var dt = DbHelper.GetDataTable("SELECT UserID, FullName, PasswordHash FROM Users WHERE Email=@e", new SqlParameter("@e", email));
        if (dt.Rows.Count == 0) { lblMsg.Text = "Invalid credentials."; return; }
        var row = dt.Rows[0];
        var stored = row["PasswordHash"].ToString();
        if (!DbHelper.VerifyHashedPassword(stored, pass)) { lblMsg.Text = "Invalid credentials."; return; }
        System.Web.Security.FormsAuthentication.SetAuthCookie(email, false);
        Session["UserID"] = Convert.ToInt32(row["UserID"]);
        Session["UserName"] = row["FullName"].ToString();
        Response.Redirect("~/User/Dashboard.aspx");
    }
}
