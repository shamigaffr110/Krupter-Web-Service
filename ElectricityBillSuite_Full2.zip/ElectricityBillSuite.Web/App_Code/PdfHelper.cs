using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace EBS.Helpers
{
    public static class PdfHelper
    {
        public static string CreateSimpleBillPdf(string outputFolder, int billId, string customerName, decimal amount, DateTime dueDate)
        {
            Directory.CreateDirectory(outputFolder);
            string filename = Path.Combine(outputFolder, $"Bill_{billId}.pdf");
            using (var fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                var doc = new Document(PageSize.A4);
                PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.AddTitle($"Bill #{billId}");
                var title = new Paragraph("ElectricityBillSuite - Bill") { Alignment = Element.ALIGN_CENTER };
                doc.Add(title);
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph($"Bill ID: {billId}"));
                doc.Add(new Paragraph($"Customer: {customerName}"));
                doc.Add(new Paragraph($"Amount Due: {amount:C}"));
                doc.Add(new Paragraph($"Due Date: {dueDate:yyyy-MM-dd}"));
                doc.Close();
            }
            return filename;
        }
    }
}
