using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace EBS.Helpers
{
    public static class DbHelper
    {
        private static string ConnString => ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString;

        public static DataTable GetDataTable(string sql, params SqlParameter[] parameters)
        {
            var dt = new DataTable();
            using (var conn = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                using (var da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
            }
            return dt;
        }

        public static object ExecuteScalar(string sql, params SqlParameter[] parameters)
        {
            using (var conn = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                conn.Open();
                return cmd.ExecuteScalar();
            }
        }

        public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using (var conn = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static string HashPassword(string password, int iterations = 10000)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] salt = new byte[16];
                rng.GetBytes(salt);
                var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations);
                byte[] hash = pbkdf2.GetBytes(32);
                byte[] hashBytes = new byte[49];
                hashBytes[0] = 0x00;
                Buffer.BlockCopy(salt, 0, hashBytes, 1, 16);
                Buffer.BlockCopy(hash, 0, hashBytes, 17, 32);
                return Convert.ToBase64String(hashBytes);
            }
        }

        public static bool VerifyHashedPassword(string storedHash, string password)
        {
            try
            {
                byte[] hashBytes = Convert.FromBase64String(storedHash);
                if (hashBytes.Length != 49 || hashBytes[0] != 0x00) return false;
                byte[] salt = new byte[16];
                Buffer.BlockCopy(hashBytes, 1, salt, 0, 16);
                byte[] stored = new byte[32];
                Buffer.BlockCopy(hashBytes, 17, stored, 0, 32);
                var iterations = int.Parse(ConfigurationManager.AppSettings["PBKDF2_Iterations"] ?? "10000");
                var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations);
                byte[] test = pbkdf2.GetBytes(32);
                for (int i = 0; i < 32; i++)
                {
                    if (test[i] != stored[i]) return false;
                }
                return true;
            }
            catch { return false; }
        }
    }
}
